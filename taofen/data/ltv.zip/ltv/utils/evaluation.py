from sklearn.metrics import mean_squared_error, mean_absolute_error

def evaluate_predictions(y_true, y_pred, scaler, y_test_diff_label):
    y_true_orig = scaler.inverse_transform(y_true.reshape(-1,1)).flatten() + y_test_diff_label
    y_pred_orig = scaler.inverse_transform(y_pred.reshape(-1,1)).flatten() + y_test_diff_label
    mse = mean_squared_error(y_true_orig, y_pred_orig)
    mae = mean_absolute_error(y_true_orig, y_pred_orig)
    return mse, mae, y_true_orig, y_pred_orig


