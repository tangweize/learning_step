import matplotlib.pyplot as plt
import pandas as pd


def plot_predictions(test_dates, y_true, y_pred, start_date=None, end_date=None, show_all_xticks=False, ax=None, highlight_dates=None):
    import matplotlib.pyplot as plt
    import pandas as pd

    df = pd.DataFrame({'date': pd.to_datetime(test_dates), 'y_true': y_true, 'y_pred': y_pred})
    if start_date is not None and end_date is not None:
        start_date, end_date = pd.to_datetime(start_date), pd.to_datetime(end_date)
        df = df[(df['date'] >= start_date) & (df['date'] <= end_date)]

    if ax is None:
        fig, ax = plt.subplots(figsize=(12,6))

    ax.plot(df['date'], df['y_true'], label='Ground Truth', color='blue')
    ax.plot(df['date'], df['y_pred'], label='Predictions', color='red', linestyle='--')
    ax.set_title('LTV Prediction vs Actual')
    ax.set_ylabel('day7_ltv_sum')
    ax.legend()
    ax.grid(True, which='both', linestyle='--', alpha=0.5)

    if show_all_xticks:
        ax.set_xticks(df['date'])
        ax.set_xticklabels([d.strftime('%Y-%m-%d') for d in df['date']], rotation=45)
    else:
        plt.xticks(rotation=45)

    # 添加 highlight 竖线
    if highlight_dates is not None:
        for d in pd.to_datetime(highlight_dates):
            ax.axvline(d, color='green', linestyle=':', linewidth=1.5)

    if ax is None:
        plt.tight_layout()
        plt.show()

def plot_relative_error(test_dates, relative_error, start_date=None, end_date=None, show_all_xticks=False, ax=None, highlight_dates=None):
    import matplotlib.pyplot as plt
    import pandas as pd

    error_df = pd.DataFrame({'date': pd.to_datetime(test_dates), 'error': relative_error})
    if start_date is not None and end_date is not None:
        start_date, end_date = pd.to_datetime(start_date), pd.to_datetime(end_date)
        error_df = error_df[(error_df['date'] >= start_date) & (error_df['date'] <= end_date)]
    daily_error = error_df.groupby('date').mean()

    if ax is None:
        fig, ax = plt.subplots(figsize=(14,6))

    ax.plot(daily_error.index, daily_error['error'], marker='o', linestyle='-', color='purple')
    ax.axhline(y=0.1, color='gray', linestyle='--', label='10% Threshold')
    ax.set_title('Daily Relative Prediction Error')
    ax.set_ylabel('Relative Error')
    ax.legend()
    ax.grid(True, which='both', linestyle='--', alpha=0.5)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:.0%}"))

    if show_all_xticks:
        ax.set_xticks(daily_error.index)
        ax.set_xticklabels([d.strftime('%Y-%m-%d') for d in daily_error.index], rotation=45)
    else:
        plt.xticks(rotation=45)

    # 添加 highlight 竖线
    if highlight_dates is not None:
        for d in pd.to_datetime(highlight_dates):
            ax.axvline(d, color='green', linestyle=':', linewidth=1.5)

    if ax is None:
        plt.tight_layout()
        plt.show()
