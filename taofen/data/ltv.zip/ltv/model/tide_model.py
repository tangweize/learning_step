import torch
import torch.nn as nn
import torch.nn.functional as F

class ResidualBlock(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim):
        super().__init__()
        self.linear1 = nn.Linear(in_dim, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, out_dim)
        self.linear_res = nn.Linear(in_dim, out_dim)
        self.dropout = nn.Dropout(0.2)
        self.layernorm = nn.LayerNorm(out_dim)
    def forward(self, x):
        h = F.relu(self.linear1(x))
        h = self.dropout(self.linear2(h))
        return self.layernorm(h + self.linear_res(x))

class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers):
        super().__init__()
        self.layers = nn.ModuleList([ResidualBlock(input_dim, hidden_dim, hidden_dim) for _ in range(num_layers)])
    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

class Decoder(nn.Module):
    def __init__(self, hidden_dim, output_dim):
        super().__init__()
        self.fc = nn.Linear(hidden_dim, output_dim)
    def forward(self, x):
        return self.fc(x)

class TiDEWithEmbedding(nn.Module):
    def __init__(self, embedding_dims, hidden_dim, num_layers, input_dim_dense, output_dim=1):
        super().__init__()
        self.embeddings = nn.ModuleList([nn.Embedding(num, dim) for num, dim in embedding_dims])
        total_emb_dim = sum(dim for _, dim in embedding_dims)
        self.encoder = Encoder(input_dim_dense + total_emb_dim, hidden_dim, num_layers)
        self.decoder = Decoder(hidden_dim, output_dim)
    def forward(self, x_cat, x_dense):
        emb = torch.cat([emb_layer(x_cat[:, i]) for i, emb_layer in enumerate(self.embeddings)], dim=1)
        x = torch.cat([x_dense, emb], dim=1)
        return self.decoder(self.encoder(x))
