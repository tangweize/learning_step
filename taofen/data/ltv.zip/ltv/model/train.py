import torch
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler

from sklearn.preprocessing import StandardScaler


def prepare_datasets(all_X, all_y, train_cnt, cat_feat_count, valid_ratio=0.15):
    # 划分训练+验证集和测试集
    X_train_valid, y_train_valid = all_X[:train_cnt], all_y[:train_cnt]
    X_test, y_test = all_X[train_cnt:], all_y[train_cnt:]

    # 再从训练+验证集中划分验证集
    valid_size = int(train_cnt * valid_ratio)
    X_train, y_train = X_train_valid[:-valid_size], y_train_valid[:-valid_size]
    X_valid, y_valid = X_train_valid[-valid_size:], y_train_valid[-valid_size:]

    # 找出 dense 特征索引
    dense_indices = [i for i in range(all_X.shape[1]) if i >= cat_feat_count]

    # 标准化 dense 特征和 y
    scaler_X, scaler_y = StandardScaler(), StandardScaler()
    X_train[:, dense_indices] = scaler_X.fit_transform(X_train[:, dense_indices])
    X_valid[:, dense_indices] = scaler_X.transform(X_valid[:, dense_indices])
    X_test[:, dense_indices] = scaler_X.transform(X_test[:, dense_indices])

    y_train = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
    y_valid = scaler_y.transform(y_valid.reshape(-1, 1)).flatten()
    y_test = scaler_y.transform(y_test.reshape(-1, 1)).flatten()

    return X_train, y_train, X_valid, y_valid, X_test, y_test, scaler_X, scaler_y



def train_model(model, train_loader, valid_loader, num_epochs=50, lr=1e-3, patience=5):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = torch.nn.MSELoss()
    best_val_loss = float('inf')
    best_model_state = None
    patience_counter = 0
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        for x_cat, x_dense, y in train_loader:
            optimizer.zero_grad()
            pred = model(x_cat, x_dense)
            loss = criterion(pred, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * x_cat.size(0)
        avg_loss = total_loss / len(train_loader.dataset)
        with torch.no_grad():
            x_val_cat, x_val_dense, y_val = next(iter(valid_loader))
            val_loss = criterion(model(x_val_cat, x_val_dense), y_val).item()
        print(f'Epoch {epoch+1}: Train Loss={avg_loss:.4f}, Val Loss={val_loss:.4f}')
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_model_state = model.state_dict()
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"Early stopping at epoch {epoch+1}")
                break
    if best_model_state:
        model.load_state_dict(best_model_state)
    return model
