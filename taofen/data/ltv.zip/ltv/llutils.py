import datetime
import joblib
import os
from tqdm import tqdm_notebook
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from lightgbm import LGBMClassifier
from sqlalchemy.engine import create_engine
from sklearn.model_selection import KFold
import yaml
from email.mime.multipart import MIMEMultipart
import pickle
import copy
import json

def read_configuration(file_name):
    with open(file_name, encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data


def load_obj(file):
    with open(file, "rb") as f:
        obj = pickle.load(f)

    return obj


def save_obj(obj, file):
    with open(file, 'wb') as f:
        pickle.dump(obj, f)


class HiveHandler(object):
    def __init__(self, db_name="mkt_mldb_tmp", user_id="mkt_ml", pwd="8!aGH1!3"):
        self.db_name = db_name
        self.user_id = user_id
        self.pwd = pwd
        self.hive_engine = self.init_engine()

    def init_engine(self):
        return create_engine("hive://%s:%s@%s@sh1-bigdata-node-92:10000/%s?auth=CUSTOM" %
                             (self.user_id, self.user_id, self.pwd, self.db_name), encoding='utf-8')

    def read_sql(self,
                 sql,
                 index_col=None,
                 coerce_float=True,
                 params=None,
                 parse_dates=None,
                 columns=None,
                 chunksize=None, ):
        return pd.read_sql(sql, self.hive_engine, index_col, coerce_float, params, parse_dates, columns, chunksize)

    def exec_sql(self, sql):
        # with self.hive_engine.begin() as conn:
        #     conn.execute(sql)
        self.hive_engine.execute(sql)




        

def load_hive_data(sql, refreash=True):
    hv = HiveHandler()
    table_name = "".join(sql.split(" "))
    cache_folder_path = "./table_cache"
    folder = os.path.exists(cache_folder_path)
    save_path = cache_folder_path + "/" + table_name + datetime.date.today().strftime("%Y-%m-%d") + ".csv"
    if not folder:
        os.makedirs(cache_folder_path)
        datas = hv.read_sql(sql)
        if refreash == False:
            datas.to_csv(save_path)
    else:
        if os.path.exists(save_path) and refreash == False:
            datas = pd.read_csv(save_path, index_col=None)
        else:
            datas = hv.read_sql(sql)
            if refreash == False:
                datas.to_csv(save_path)
    return datas


def get_data(sql_data):
    return load_hive_data(sql_data)



def load_data(sql_data, model_days, refreash=True, today=None):
    sample = load_hive_data(sql_data, refreash)
    if today is None:
        today = datetime.datetime.now()
    train_right_date = (today + datetime.timedelta(days=-model_days - 7)).strftime('%Y-%m-%d')
    train_left_date = (today + datetime.timedelta(days=-model_days - 6 - 14)).strftime('%Y-%m-%d')
    try:
        if "install_date" in sample.columns.values and "activate_date" not in sample.columns.values:
            sample.rename(columns={"install_date": "activate_date"}, inplace=True)

        print('%s到%s的数据：%d' % (sample['activate_date'].min(), sample['activate_date'].max(), len(sample)))

        train_samples = sample[(sample['activate_date'] >= train_left_date) & (sample['activate_date'] <= train_right_date)]
    except:
        print("没有激活日期字段")
    try:
        print("训练集： ", train_left_date, train_right_date)
        zheng_sample = train_samples[train_samples['label'] == 1]
        print('训练集中正样本的数量：%d' % len(zheng_sample))
        fu_sample = train_samples[train_samples['label'] == 0]
        print('训练集中负样本的数量：%d' % len(fu_sample))
    except:
        print("该表没有label字段")
    try:
        rate1 = round(len(zheng_sample) / len(fu_sample), 3)
    except:
        rate1 = 0.0
    print('训练集中正负样本比值有：%s' % str(rate1))

    if "Unnamed: 0" in sample.columns:
        sample = sample.drop(columns=["Unnamed: 0"])

    return sample


def three_sigma(tp_series: pd.Series):
    # 求平均值
    mean_value = tp_series.mean()
    # 求标准差
    std_value = tp_series.std()
    # 位于(μ-4σ,μ+4σ)区间的数据是正常的，不在这个区间的数据为异常的
    # ser1中的数值小于μ-3σ或大于μ+3σ均为异常值
    # 一旦发现有异常值，就标注为True，否则标注为False

    # 小改了下参数 μ+4σ
    left_rule = (mean_value - 4 * std_value > tp_series)

    right_rule = (mean_value + 4 * tp_series.std() < tp_series)
    # 返回异常值的位置索引
    left_index = np.arange(tp_series.shape[0])[left_rule]
    right_index = np.arange(tp_series.shape[0])[right_rule]
    # 获取异常数据
    left_outrange = tp_series.iloc[left_index]
    right_outrange = tp_series.iloc[right_index]

    left_outrange_index = left_outrange.index
    right_outrange_index = right_outrange.index

    tp_series[left_outrange_index] = left_outrange.max()
    tp_series[right_outrange_index] = right_outrange.min()

    return tp_series


# 测试集没有label
def Guiyin_cv(model_set, res_df, test_data, input_features, columns, model_days=1, today=None):
    if type(res_df) == type(None):
        res_df = pd.DataFrame(columns=columns)
    res_dict = {}
    for col in columns:
        res_dict[col] = []

    pred_score = None

    for model in model_set:
        if type(pred_score) == type(None):
            pred_score = model.predict_proba(test_data[input_features])
        else:
            pred_score += model.predict_proba(test_data[input_features])

    pred_score = pred_score / len(model_set)

    # columns[-1] 是 pred_score
    for col in columns[:-1]:
        res_dict[col] = test_data[col].values
    res_dict[columns[-1]] = pred_score[:, 1]

    prev = pd.DataFrame(res_dict)
    res_df = res_df.append(prev, ignore_index=True)

    # 如果日期是 日期类型，转成字符串固定格式，年月日。
    if res_df.dtypes['activate_date'] == 'datetime64[ns]':
        res_df['activate_date'] = res_df['activate_date'].apply(lambda x: x.strftime("%Y-%m-%d"))

    res_df['dim_ad_channel_name'] = '今日头条'
    res_df['model_days'] = 'day' + str(model_days)
    if today is None:
        today = datetime.datetime.now()
    res_df['predict_date'] = today.strftime('%Y-%m-%d')

    res_df.rename(columns={"pred_score": "1_label"}, inplace=True)

    return res_df


def features_checking(Feature_List, train_data, test_data, Generate_Features):
    canditate_features = []
    all_cols = train_data.columns.values
    numeric_features = []
    res = []
    for i in Feature_List:
        if "_input" in i:
            # 原特征名字
            feature_name = i[:-len("_input")]
            if feature_name not in canditate_features and feature_name not in Generate_Features and feature_name in all_cols:
                canditate_features.append(feature_name)
                if Feature_List[i]['feature_type'] == 'numerical':
                    numeric_features.append(feature_name)

    for cf in canditate_features:
        train_null = sum(train_data[cf].isna()) / len(train_data)
        test_null = sum(test_data[cf].isna()) / len(test_data)
        zero_ratio_train = 0.0
        zero_ratio_test = 0.0
        try:
            zero_ratio_train = (train_data[cf] == 0).sum() / len(train_data)
            zero_ratio_test = (test_data[cf] == 0).sum() / len(test_data)
        except:
            print(cf, '特征不是标准数值型！')

        if abs(train_null - test_null) >= 0.13 or (train_null > 0.99) or (test_null > 0.99) or abs(
                zero_ratio_train - zero_ratio_test) >= 0.2:
            res.append(cf)

    f2nullCnt = {}
    # value是 数组， 0 是 训练集的该特征缺失率，1 是当天数据的该特征缺失率
    for cf in canditate_features:
        f2nullCnt[cf] = [sum(test_data[cf].isna()) / len(test_data), sum(train_data[cf].isna()) / len(train_data)]
    return res, f2nullCnt


def send_main(msg_content, subject):
    subject = '流量模型' + subject + '特征异常警告'
    # 发信方的信息：发信邮箱，QQ 邮箱授权码
    from_addr = 'tangweize@tuhu.cn'
    password = 'w2TrcT3ncb79X9ki'
    # 收信方邮箱
    recievers = ['zhengyiyuan@tuhu.cn', 'liqian3@tuhu.cn', 'tangweize@tuhu.cn', 'yangtian@tuhu.cn']
    # recievers = ['tangweize@tuhu.cn']
    # 发信服务器
    smtp_server = 'smtp.exmail.qq.com'

    msg = MIMEText(msg_content, 'plain', 'utf-8')
    # 邮件头信息
    msg['From'] = Header('Liuliang_Model')  # 发送者
    msg['Subject'] = Header(subject, 'utf-8')  # 邮件主题

    try:
        smtpobj = smtplib.SMTP_SSL(smtp_server)
        # 建立连接--qq邮箱服务和端口号（可百度查询）
        smtpobj.connect(smtp_server, 465)
        # 登录--发送者账号和口令
        smtpobj.login(from_addr, password)
        # 发送邮件
        smtpobj.sendmail(from_addr, recievers, msg.as_string())
        print("邮件发送成功")
    except smtplib.SMTPException:
        print("无法发送邮件")
    finally:
        # 关闭服务器
        smtpobj.quit()


def save_model_pred_results(res_csv_ad, folder, file_name, raw_samples):
    if not os.path.exists(folder):
        os.mkdir(folder)
    save_path = "/".join([folder, file_name])
    save_path = "./" + save_path
    res = pd.merge(res_csv_ad, raw_samples, on=['deviceid', 'activate_date'], how='left')
    # res.to_csv(save_path)
    return save_path, res


def generate_feature_importance(model, save_path, input_features):
    feature_importance = pd.Series(model.booster_.feature_importance(importance_type='gain'))
    feature_impo = pd.DataFrame(feature_importance, columns=['important'])
    feature_impo['name'] = None
    for i, v in zip(feature_impo.index.values, input_features):
        feature_impo.loc[i, 'name'] = v
    feature_impo.to_csv(save_path)


## 将某几列取最大合并成新的一列
def multiCol2type(need_to_transfer, target_col, samples):
    multi = samples[need_to_transfer].values
    div = multi / np.sum(multi, axis=1).reshape(-1, 1)
    arg_idx = np.argwhere(div > 0.55)
    samples[target_col] = None
    samples.loc[arg_idx[:, 0], target_col] = arg_idx[:, 1]
    return samples


# 消耗加权gap计算
def save_cost_mid_results(res_csv, folder, file_name):
    if not os.path.exists(folder):
        os.mkdir(folder)
    save_path = "/".join([folder, file_name])
    save_path = "./" + save_path
    res_csv.to_csv(save_path)


def cost_weight_gap(ad_res: pd.DataFrame, windows):
    if 'Unnamed: 0' in ad_res:
        ad_res = ad_res.drop(['Unnamed: 0'], axis=1)

    # 如果 激活日期是字符串类型，需要将其转化为 日期类型
    if ad_res['activate_date'].dtype == 'object':
        ad_res['activate_date'] = ad_res['activate_date'].astype("datetime64[ns]")

    min_date = ad_res['activate_date'].min()
    max_date = ad_res['activate_date'].max()

    delta_days = (max_date - min_date).days
    left = min_date
    right = left + datetime.timedelta(windows - 1)
    if right > max_date:
        print("该结果数据范围内的日期区间 不支持 该windows取值，请调小windwos")
        return None
    while right <= max_date:
        temp_interval = ad_res[(ad_res['activate_date'] >= left) & (ad_res['activate_date'] <= right)].copy()
        res_csv_ad_pred = temp_interval.groupby(
            ['advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days'])[
            ['pred_score']].sum().reset_index()

        res_csv_ad_true = temp_interval.groupby(
            ['advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days'])[
            ['label']].sum().reset_index()

        res_csv_ad_cost = temp_interval.groupby(
            ['advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days'])[
            ['cost']].sum().reset_index()

        res111 = pd.merge(res_csv_ad_pred, res_csv_ad_true, how='left',
                          on=['advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days'])

        res = pd.merge(res111, res_csv_ad_cost, how='left',
                       on=['advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days'])

        res['abs_gap'] = (abs(res['pred_score'] - res['label'])) / res['label']

        # 将分母为0的gap 置为0
        res['abs_gap'] = res['abs_gap'].replace([np.inf, -np.inf], 0)

        res['cost_gap'] = res['abs_gap'] * (res['cost'] / res['cost'].sum())

        save_cost_mid_results(res, "ad_results",
                              str(windows) + "windows" + left.strftime('%Y-%m-%d') + "->" + right.strftime(
                                  '%Y-%m-%d') + ".csv")
        right += datetime.timedelta(1)
        left += datetime.timedelta(1)

    # print(res['abs_gap'].sum() / len(res))
    # print(left.strftime('%Y-%m-%d'), "   ",right.strftime('%Y-%m-%d'), res['cost_gap'].sum())
    print(res['cost_gap'].sum())
    return res['cost_gap'].sum()


def null_features(f2null_ratio, count=10, day_x=1):
    feature_import = pd.read_csv(
        "./" + "mid_results" + "/day" + str(day_x) + "features_importance_GBM_" + datetime.datetime.now().strftime(
            "%Y-%m-%d") + ".csv", index_col=0)

    city_features = City_Features
    null_city_features = {}
    for temp_feat in f2null_ratio:
        if temp_feat in city_features:
            null_city_features[temp_feat] = f2null_ratio[temp_feat]

    f2null_ratio = null_city_features
    null_num_top10 = sorted(f2null_ratio.items(), key=lambda x: x[1], reverse=True)
    fe2imp = {}
    for li in feature_import.values:
        fe2imp[li[1]] = li[0]

    fe2imp_rank = sorted(fe2imp.items(), key=lambda x: x[1], reverse=True)
    f2rank = {}
    rank = 1
    for fe in fe2imp_rank:
        f2rank[fe[0]] = rank
        rank += 1

    res = {}
    for null_fe in null_num_top10:
        fe_name = null_fe[0]
        if fe_name in f2rank:
            count -= 1
            res[fe_name] = {"重要度排名": "第" + str(f2rank[fe_name]), "测试集缺失率": round(null_fe[1][0], 5),
                            "训练集集": round(null_fe[1][1], 5)}
        if count == 0:
            break

    return res


def null_features_no_city(f2null_ratio, category_features, count=10, day_x=1):
    city_features = City_Features
    feature_import = pd.read_csv(
        "./" + "mid_results" + "/day" + str(day_x) + "features_importance_GBM_" + datetime.datetime.now().strftime(
            "%Y-%m-%d") + ".csv", index_col=0)
    null_num_top10 = sorted(f2null_ratio.items(), key=lambda x: x[1], reverse=True)
    fe2imp = {}
    for li in feature_import.values:
        fe2imp[li[1]] = li[0]

    fe2imp_rank = sorted(fe2imp.items(), key=lambda x: x[1], reverse=True)
    f2rank = {}
    rank = 1
    for fe in fe2imp_rank:
        f2rank[fe[0]] = rank
        rank += 1

    res = {}
    for null_fe in null_num_top10:
        fe_name = null_fe[0]
        if fe_name in f2rank and fe_name not in city_features and fe_name not in category_features:
            count -= 1
            res[fe_name] = {"重要度排名": "第" + str(f2rank[fe_name]), "测试集缺失率": round(null_fe[1][0], 5),
                            "训练集集": round(null_fe[1][1], 5)}
        if count == 0:
            break

    return res


def date2str(date):
    return date.strftime("%Y-%m-%d")


def str2date(date_str: str):
    return datetime.datetime.strptime(date_str, "%Y-%m-%d")


# 按照某个类别特征进行采样，使其和test 分布一致
def cate_features_sampling(train_datasets, test_datasets, category='city_name'):
    category_sets = set(test_datasets[category].values)

    # 14天牺牲一天的数据量 来保持train和test 城市分布一致
    need_sampling_samples_num = len(train_datasets) - len(train_datasets) // 3
    category2ratio = {}

    for category_value in category_sets:
        category2ratio[category_value] = (test_datasets[category] == category_value).sum() / len(test_datasets)

    category2sampling_num = {}

    for ft in category2ratio:
        category2sampling_num[ft] = int(category2ratio[ft] * need_sampling_samples_num)
    print(category2sampling_num)
    # 需要采样的类别数
    cate_num = len(category2sampling_num)
    print(train_datasets['activate_date'].dtype)

    if train_datasets['activate_date'].dtype == "datetime64[ns]":
        train_datasets['activate_date'] = train_datasets['activate_date'].apply(lambda x: x.strftime("%Y-%m-%d"))

    ########################################33
    newest_date = train_datasets['activate_date'].max()

    oldest_date = str2date(train_datasets['activate_date'].min())

    point_date = str2date(newest_date) + datetime.timedelta(1)

    res_index = []
    while point_date >= oldest_date:
        point_date = point_date + datetime.timedelta(-1)
        temp_date_samples = train_datasets[train_datasets['activate_date'] == date2str(point_date)]

        # 样本进行采样
        for feature in category2sampling_num:
            temp_date_samples_indexs = list(temp_date_samples[temp_date_samples[category] == feature].index.values)
            if category2sampling_num[feature] <= 0:
                continue
            if len(temp_date_samples_indexs) > category2sampling_num[feature]:
                res_index = res_index + temp_date_samples_indexs[:category2sampling_num[feature]]
                category2sampling_num[feature] = 0
            else:
                category2sampling_num[feature] -= len(temp_date_samples_indexs)
                res_index = res_index + temp_date_samples_indexs
    for i in category2sampling_num:
        if category2sampling_num[i] > 0:
            print(i, category2sampling_num[i])

    return train_datasets.loc[res_index]


# 类别特征交叉
def category_feature_crossing(features, df):
    cross_features = []
    length = len(features)
    for f1 in range(len(features)):
        for f2 in range(f1, len(features)):
            if features[f1] != features[f2]:
                tp_feature_name = features[f1] + "_" + features[f2]
                df[tp_feature_name] = df[features[f1]] * df[features[f2]]
                cross_features.append(tp_feature_name)
    return df, cross_features


# 数值型特征交叉
def numeric_feature_crossing(features, df):
    return None


from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage


def send_mail_feature(MODEL_NAME, alarm_level, table, train_date, test_date, yester_date, model_days='day1',
                      file_pngs=[],
                      is_offline=False):
    pd.set_option('display.max_colwidth', -1)
    df_html1 = table[0].to_html(escape=False)
    df_html2 = table[1].to_html(escape=False)
    df_html3 = table[2].to_html(escape=False)
    df_html4 = table[3].to_html(escape=False)

    subject = '[流量模型' + MODEL_NAME + '特征监控]'
    subject = subject + model_days + "(" + alarm_level + ")"

    head = \
        """
        <head>
            <meta charset="utf-8">
            <STYLE TYPE="text/css" MEDIA=screen>
                table.dataframe {
                    border-collapse: collapse;
                    border: 2px solid #a19da2;
                    /*居中显示整个表格*/
                    margin: auto;
                }
                table.dataframe thead {
                    border: 2px solid #91c6e1;
                    background: #f1f1f1;
                    padding: 10px 10px 10px 10px;
                    color: #333333;
                }
                table.dataframe tbody {
                    border: 2px solid #91c6e1;
                    padding: 10px 10px 10px 10px;
                }
                table.dataframe tr {
                }
                table.dataframe th {
                    vertical-align: top;
                    font-size: 14px;
                    padding: 10px 10px 10px 10px;
                    color: #105de3;
                    font-family: arial;
                    text-align: center;
                }
                table.dataframe td {
                    text-align: center;
                    padding: 10px 10px 10px 10px;
                }
                body {
                    font-family: 宋体;
                }
                h1 {
                    color:  #000000;
                    font-size: 15px;
                }
                div.header h2 {
                    color: #000000;
                    font-family: 黑体;
                }
                div.content h2 {
                    text-align: center;
                    font-size: 28px;
                    text-shadow: 2px 2px 1px #de4040;
                    color: #fff;
                    font-weight: bold;
                    background-color: #008eb7;
                    line-height: 1.5;
                    margin: 20px 0;
                    box-shadow: 10px 10px 5px #888888;
                    border-radius: 5px;
                }
                h3 {
                    font-size: 16px;
                    background-color: rgba(0, 2, 227, 0.71);
                    text-shadow: 2px 2px 1px #de4040;
                    color: rgba(239, 241, 234, 0.99);
                    line-height: 1.5;
                }
                h4 {
                    color: #e10092;
                    font-family: 楷体;
                    font-size: 10px;
                    text-align: left;
                }
                td img {
                    /*width: 60px;*/
                    max-width: 300px;
                    max-height: 300px;
                }
            </STYLE>
        </head>
        """
    body = \
        """
        <body>
        <div align="center" class="header">
            <!--标题部分的信息-->
            <h1 align="center"> </h1>
        </div>
        <hr>
        <div class="content">
            <!--正文内容-->
            <h2> </h2>

            <div>
                <h4> 无警告 ： 训练集和测试集缺失率 <= 5%  </h4>
                <h4> 轻度警告： 训练集和测试集缺失率 > 5%  </h4>
                <h4> 中度警告： 训练集和测试集缺失率 > 10%   </h4>
                <h4> 严重警告： 训练集和测试集缺失率 > 15%   </h4>
                <h4> 0_ratio ： 附件图特征后缀0_ratio表示 0值率  </h4>
                <h4> null_ratio： 附件图特征后缀0_ratio表示 空值率  </h4>
                <h4> 展示某特征的null_ratio 或者 0_ratio 取决于 该特征下，空值和0值哪个波动大  </h4>
            </div>



            <div>
                <h3> {today}日 与 {train_date} 日（训练集）缺失率对比 </h3>
                {df_html1}
            </div>

            <div>
                <h3> {today}日 与 {yesterday} 日缺失率对比 </h3>
                {df_html2}
            </div>

             <div>
                <h3> {today}日 分别与 {train_date} 日（训练集）每一天缺失率对比 </h3>
                {df_html3}
            </div>

            <div>
                <h3> 重要特征特征具体缺失率 </h3>
                {df_html4}
            </div>

            <hr>
            <p style="text-align: center">
            </p>
        </div>
        </body>
        """.format(today=test_date, yesterday=yester_date, train_date=train_date, df_html1=df_html1, df_html2=df_html2,
                   df_html3=df_html3, df_html4=df_html4)

    msg_content = "<html>" + head + body + "</html>"
    msg_content = msg_content.replace('\n', '').encode("utf-8")

    msg = MIMEMultipart()

    msg['from'] = 'tangweize@tuhu.cn'
    msg['to'] = 'tangweize@tuhu.cn'  # 多个收件人的邮箱应该放在字符串中,用字符分隔, 然后用split()分开,不能放在列表中, 因为要使用encode属性
    msg['subject'] = subject
    msg.attach(MIMEText(msg_content, "html", "utf-8"))

    for png_file in file_pngs:
        attachment_1 = MIMEText(open(png_file, 'rb').read(), "base64", "utf-8")
        attachment_1['content-Type'] = 'application/octet-stream'
        attachment_1['content-Disposition'] = "attachment;filename= " + "'" + png_file.split("/")[-1] + "'"
        msg.attach(attachment_1)
    smtpHost = 'smtp.exmail.qq.com'
    port = 465
    smtp = smtplib.SMTP_SSL(smtpHost, port)  # 需要一个安全的连接，用SSL的方式去登录得用SMTP_SSL，之前用的是SMTP（）.端口号465或587
    smtp.login('tangweize@tuhu.cn', 'w2TrcT3ncb79X9ki')  # 发送方的邮箱，和授权码（不是邮箱登录密码）
    if is_offline == False:
        smtp.sendmail('tangweize@tuhu.cn',
                      ['zhengyiyuan@tuhu.cn', 'liqian3@tuhu.cn', 'tangweize@tuhu.cn', 'yangtian@tuhu.cn',
                       'zhangqixian@tuhu.cn'], str(msg))  # 注意, 这里的收件方可以是多个邮箱,用";"分开, 也可以用其他符号
    else:
        smtp.sendmail('tangweize@tuhu.cn', ['tangweize@tuhu.cn'], str(msg))  # 注意, 这里的收件方可以是多个邮箱,用";"分开, 也可以用其他符号


def feature_compare_between_datasets(train_data, test_data, numeric_features, cate_features, threshold=0.05, topN=10):
    feature_ratio_diff = {}

    is_alarm = 0
    # 数值型特征统计
    for n_feature in numeric_features:
        null_ratio_train = train_data[n_feature].isna().sum() / len(train_data)
        zero_ratio_train = (train_data[n_feature] == 0).sum() / len(train_data)

        null_ratio_test = test_data[n_feature].isna().sum() / len(test_data)
        zero_ratio_test = (test_data[n_feature] == 0).sum() / len(test_data)

        # 如果空值率 比 1%还少，可能更注重0值率
        null_ratio_diff = round(abs(null_ratio_test - null_ratio_train), 3)
        zero_ratio_diff = round(abs(zero_ratio_test - zero_ratio_train), 3)

        if null_ratio_diff < zero_ratio_diff:
            feature_ratio_diff[n_feature + " 0值率差异"] = zero_ratio_diff
        else:
            feature_ratio_diff[n_feature + " 空值率差异"] = null_ratio_diff

    for c_feature in cate_features:
        null_ratio_train = train_data[c_feature].isna().sum() / len(train_data)
        null_ratio_test = test_data[c_feature].isna().sum() / len(test_data)

        feature_ratio_diff[n_feature + " 空值率差异"] = round(abs(null_ratio_test - null_ratio_train), 3)

    # 要么取前50，要么前 相差率 > 10

    sorted_features = sorted(feature_ratio_diff.items(), key=lambda x: x[1], reverse=True)

    city_features = City_Features

    # 预警等级， 1，2，3
    if sorted_features[0][1] > 0.05 and sorted_features[0][1] <= 0.1:
        is_alarm = 1
    elif sorted_features[0][1] > 0.1 and sorted_features[0][1] <= 0.15:
        is_alarm = 2
    elif sorted_features[0][1] > 0.15:
        is_alarm = 3

    print(is_alarm)
    alarm_features = []
    alarm_yuzhi = []

    alarm_city_Features = []
    alarm_city_yuzhi = []
    for tuple_ in sorted_features:
        key_ = tuple_[0]
        value_ = tuple_[1]
        if key_[:-6] in city_features:
            alarm_city_Features.append(key_)
            alarm_city_yuzhi.append(str(round(value_ * 100, 3)) + "%")
        else:
            alarm_features.append(key_)
            alarm_yuzhi.append(str(round(value_ * 100, 3)) + "%")

    # 和测试集的对比
    res_alarm = pd.DataFrame({"feature": alarm_features[:topN] + ["以下城市特征"] + alarm_city_Features[:topN],
                              "diff": alarm_yuzhi[:topN] + [''] + alarm_city_yuzhi[:topN]})

    return res_alarm, is_alarm

    # res_alarm = pd.concat(res_alarm, )


def feature_compare_between_every_data(train_data_all_days, test_data, numeric_features, cate_features, threshold=0.05,
                                       topN=10):
    feature_ratio_diff = {}

    is_alarm = 0
    # 数值型特征统计

    col_level1 = []
    col_level2 = []
    t_dates = list(set(train_data_all_days['activate_date'].values))
    t_dates.sort()
    data = []
    for temp_date in t_dates:

        train_data = train_data_all_days[train_data_all_days['activate_date'] == temp_date]
        col_level1.append(temp_date)
        col_level1.append(temp_date)

        col_level2.append('feature')
        col_level2.append('diff')

        for n_feature in numeric_features:
            null_ratio_train = train_data[n_feature].isna().sum() / len(train_data)
            zero_ratio_train = (train_data[n_feature] == 0).sum() / len(train_data)

            null_ratio_test = test_data[n_feature].isna().sum() / len(test_data)
            zero_ratio_test = (test_data[n_feature] == 0).sum() / len(test_data)

            # 如果空值率 比 1%还少，可能更注重0值率
            null_ratio_diff = round(abs(null_ratio_test - null_ratio_train), 3)
            zero_ratio_diff = round(abs(zero_ratio_test - zero_ratio_train), 3)

            if null_ratio_diff < zero_ratio_diff:
                feature_ratio_diff[n_feature + " 0值率差异"] = zero_ratio_diff
            else:
                feature_ratio_diff[n_feature + " 空值率差异"] = null_ratio_diff

        for c_feature in cate_features:
            null_ratio_train = train_data[c_feature].isna().sum() / len(train_data)
            null_ratio_test = test_data[c_feature].isna().sum() / len(test_data)

            feature_ratio_diff[n_feature + " 空值率差异"] = round(abs(null_ratio_test - null_ratio_train), 3)

        # 要么取前50，要么前 相差率 > 10

        sorted_features = sorted(feature_ratio_diff.items(), key=lambda x: x[1], reverse=True)

        city_features = City_Features

        # 预警等级， 1，2，3

        alarm_features = []
        alarm_yuzhi = []

        alarm_city_Features = []
        alarm_city_yuzhi = []
        for tuple_ in sorted_features:
            key_ = tuple_[0]
            value_ = tuple_[1]
            if key_[:-6] in city_features:
                alarm_city_Features.append(key_)
                alarm_city_yuzhi.append(str(round(value_ * 100, 3)) + "%")
            else:
                alarm_features.append(key_)
                alarm_yuzhi.append(str(round(value_ * 100, 3)) + "%")
        data.append(alarm_features[:topN] + ["以下城市特征"] + alarm_city_Features[:topN])
        data.append(alarm_yuzhi[:topN] + [''] + alarm_city_yuzhi[:topN])

    # 和测试集的对比
    res_alarm = pd.DataFrame(np.array(data).T, columns=[col_level1, col_level2])

    return res_alarm, is_alarm


def alarm_for_mail(MODEL_NAME, train_data, test_data, yesterday_data, numeric_features, cate_features,
                   table4=pd.DataFrame(),
                   model_day='day1', file_pngs=[], is_offline=False):
    alarm_level = ['无警告', "轻度警告", "中度警告", "严重警告"]

    table1 = pd.DataFrame()
    table2 = pd.DataFrame()
    table3 = pd.DataFrame()

    table1, islarm = feature_compare_between_datasets(yesterday_data, test_data, numeric_features, cate_features)

    table3, islarm = feature_compare_between_every_data(train_data, test_data, numeric_features, cate_features)

    table2, islarm1 = feature_compare_between_datasets(train_data, test_data, numeric_features, cate_features)

    train_date_interval = train_data['activate_date'].min()[5:] + "~" + train_data['activate_date'].max()[5:]
    test_date_ = test_data['activate_date'].max()[5:]
    yester_date = yesterday_data['activate_date'].max()[5:]
    print("--------------------------------------------------------------------------------------------------")
    print(islarm1, alarm_level[islarm1])
    send_mail_feature(MODEL_NAME, alarm_level[islarm1], [table2, table1, table3, table4], train_date_interval,
                      test_date_,
                      yester_date, model_day, file_pngs, is_offline)


def generate_import_feature(dic1, dic2):
    features = []
    important_rank = []
    null_ratio_test = []
    null_ratio_train = []

    for i in dic1:
        features.append(i)
        important_rank.append(dic1[i]['重要度排名'])
        null_ratio_test.append(dic1[i]['测试集缺失率'])
        null_ratio_train.append(dic1[i]['训练集集'])

    features.append("以下城市特征")
    important_rank.append(" ")
    null_ratio_test.append(" ")
    null_ratio_train.append(" ")

    for i in dic2:
        features.append(i)
        important_rank.append(dic2[i]['重要度排名'])
        null_ratio_test.append(dic2[i]['测试集缺失率'])
        null_ratio_train.append(dic2[i]['训练集集'])
    table4 = pd.DataFrame(
        {'features': features, '重要度排名': important_rank, "测试集缺失率": null_ratio_test, "训练集缺失率": null_ratio_train})

    return table4


from tqdm import tqdm_notebook
import matplotlib.pyplot as plt


def plot_every_day(raw_samples, plot_features, cat_features, file_name, zeor_or_null_flag="None"):
    plot_dates = list(set(raw_samples['activate_date'].values))
    plot_dates.sort()
    plt.figure(figsize=(20, 10), dpi=200)
    date = plot_dates
    city_features = City_Features

    label_datas = []
    for ld in date:
        label_datas.append(ld[5:])

    if zeor_or_null_flag == "None":
        for feature in tqdm_notebook(plot_features):

            zeor_or_null = -1
            data = []

            # 0值率和空值率 谁大，看谁的波动
            for temp_date in date:
                train_data = raw_samples[raw_samples['activate_date'] == temp_date]
                null_ratio_train = train_data[feature].isna().sum() / len(train_data)
                zero_ratio_train = (train_data[feature] == 0).sum() / len(train_data)
                if zeor_or_null == -1:
                    if null_ratio_train < zero_ratio_train:
                        zeor_or_null = 1
                    else:
                        zeor_or_null = 0

                # 计算0值率
                if zeor_or_null == 1:
                    data.append(zero_ratio_train)
                # 计算空值率
                else:
                    data.append(null_ratio_train)

            if zeor_or_null == 0:
                plt.plot(label_datas, data, label=feature + " null_ratio")
            else:
                plt.plot(label_datas, data, label=feature + " 0_ratio")
    elif zeor_or_null_flag == "0":
        for feature in tqdm_notebook(plot_features):
            data = []

            # 0值率和空值率 谁大，看谁的波动
            for temp_date in date:
                train_data = raw_samples[raw_samples['activate_date'] == temp_date]
                zero_ratio_train = (train_data[feature] == 0).sum() / len(train_data)

                data.append(zero_ratio_train)

            plt.plot(label_datas, data, label=feature + " 0_ratio")

    elif zeor_or_null_flag == "null":
        for feature in tqdm_notebook(plot_features):
            data = []

            # 0值率和空值率 谁大，看谁的波动
            for temp_date in date:
                train_data = raw_samples[raw_samples['activate_date'] == temp_date]
                null_ratio_train = train_data[feature].isna().sum() / len(train_data)

                data.append(null_ratio_train)

            plt.plot(label_datas, data, label=feature + " null_ratio")

    plt.legend()
    plt.savefig(file_name)
    return file_name


from sklearn.metrics import accuracy_score, precision_score, recall_score, classification_report, confusion_matrix, \
    roc_curve, roc_auc_score, f1_score
import numpy as np


def calculate_indexs(sample_1, valid_res, split=1):
    if len(valid_res) == 0:
        for i in np.arange(0.01, 0.31, 0.01):
            i = round(i, 2)
            valid_res[i] = {}
            valid_res[i]['precision'] = 0
            valid_res[i]['recall'] = 0
            valid_res[i]['f1_score'] = 0

    for i in np.arange(0.01, 0.31, 0.01):
        col = 'yuzhi_' + str(int(i * 100))
        sample_1[col] = sample_1.apply(lambda a: 1 if a['pred_score'] >= i else 0, axis=1)

    sample_1['label'] = sample_1['label'].astype(int)
    for i in np.arange(0.01, 0.31, 0.01):
        key = 'yuzhi_' + str(int(i * 100))
        i = round(i, 2)
        valid_res[i]['precision'] += round(precision_score(sample_1['label'].values, sample_1[key].values) / split, 4)
        valid_res[i]['recall'] += round(recall_score(sample_1['label'].values, sample_1[key].values) / split, 4)
        valid_res[i]['f1_score'] += round(f1_score(sample_1['label'], sample_1[key].values) / split, 4)

    return valid_res


# 将 calculate_indexs 函数输出的结果，求最大
def max_index_threshold(valid_res):
    precision_list = []
    recall_list = []
    f1_score_list = []

    for threshold in valid_res:
        precision_list.append((threshold, valid_res[threshold]['precision']))
        recall_list.append((threshold, valid_res[threshold]['recall']))
        f1_score_list.append((threshold, valid_res[threshold]['f1_score']))

    res = {}

    res['max_precision_threshold'] = sorted(precision_list, key=lambda x: x[1], reverse=True)[0][0]
    res['max_recall_threshold'] = sorted(recall_list, key=lambda x: x[1], reverse=True)[0][0]
    res['max_f1_threshold'] = sorted(f1_score_list, key=lambda x: x[1], reverse=True)[0][0]

    return res


def null_feature_alarm(MODEL_NAME, null_features, exclude_columns, alarm_date, model_days, is_offline=False, model_path = "mid_results"):
    need_alarm_col = []
    for ae in null_features:
        if ae not in exclude_columns:
            need_alarm_col.append(ae)

    ### 特征报警#####
    if len(need_alarm_col) > 0:
        msg_content = ""
        msg_content += "、".join(need_alarm_col) + " \n 以上特征训练集和测试集缺失率差 大于10%。或者特征缺失率已大于99%。\n"
        msg_content += "已对激活日为" + alarm_date + "的day" + str(model_days) + "模型进行降级操作。"
        if is_offline == False:
            send_main(msg_content, MODEL_NAME)
        else:
            print("========离线报警=========", need_alarm_col)
        print("特征报警")

    today = datetime.datetime.now()
    features_file = alarm_date + "_day" + str(model_days) + "_null_features.pkl"
    print("\n正在将该日的  【不可用特征】  保存至", features_file)
    need_alarm_col_filename = "/".join([model_path, features_file])
    save_obj(need_alarm_col, need_alarm_col_filename)

    return need_alarm_col


def feature_monitoring(MODEL_NAME, raw_samples, startdate, enddate, validate_date, category_features, numeric_features,
                       f2null_ratio, model_days, is_offline=False):
    train_data_spec = raw_samples[(raw_samples['activate_date'] >= startdate)
                                  & (raw_samples['activate_date'] <= enddate)].copy()
    test_data_spec = raw_samples[raw_samples['activate_date'] == validate_date].copy()
    yesterday_data_spec = raw_samples[
        raw_samples['activate_date'] == (str2date(validate_date) + datetime.timedelta(days=- 1)).strftime(
            '%Y-%m-%d')].copy()

    numeric_feaaa = numeric_features

    features_null_ratio_top_10 = null_features(f2null_ratio, count=10, day_x=model_days)
    no_city_features_null_ratio_20 = null_features_no_city(f2null_ratio, category_features, count=20, day_x=model_days)
    no_city_features_null_ratio = null_features_no_city(f2null_ratio, category_features, count=10, day_x=model_days)

    table4 = generate_import_feature(no_city_features_null_ratio_20, features_null_ratio_top_10)

    plot_features = list(features_null_ratio_top_10.keys()) + list(no_city_features_null_ratio.keys())

    # 城市特征
    file_pngs = []
    folder = "./mid_results/"
    file_pngs.append(plot_every_day(raw_samples, list(features_null_ratio_top_10.keys()), category_features,
                                    folder + 'day' + str(model_days) + "city_features.png"))
    # 非城市特征
    file_pngs.append(plot_every_day(raw_samples, list(no_city_features_null_ratio.keys()), category_features,
                                    folder + 'day' + str(model_days) + "no_city_features.png"))
    # 类别特征
    file_pngs.append(plot_every_day(raw_samples, category_features, category_features,
                                    folder + 'day' + str(model_days) + "category_features.png"))

    alarm_for_mail(MODEL_NAME, train_data_spec, test_data_spec, yesterday_data_spec, numeric_feaaa, category_features,
                   table4,
                   'day' + str(model_days), file_pngs, is_offline)


def date_to_longdays(columns, df, metrix='none', model_days=1):
    # 判断是几日模型，如果是 次日，三日可以穿越个一两天
    none_date = datetime.datetime.strptime("1990-12-31", "%Y-%m-%d")
    if df.dtypes['activate_date'] != 'datetime64[ns]':
        df['activate_date'] = df['activate_date'].apply(str2date)
    print("开始处理日期")
    for col in columns:
        # 如果本来为空的，则给他置为9999
        none_indexs = df[df[col] >= 9999].index
        df.loc[none_indexs, col] = 9999

        sub_df = df[df[col] < (model_days - 1) * -1].index
        df.loc[sub_df, col] = 9999
    df[col] = df[col].apply(int)
    print("处理日期结束")
    return df


# 保存虚拟回调 csv
# v2 版本
def save_virtual_callback_v2(save_folder, save_path, res_csv_ad):
    XNHD_save_path = "/".join([save_folder, save_path])
    XNHD_save_path = "./" + XNHD_save_path
    now_date_time = datetime.datetime.now()
    folder_name = os.getcwd().split('/')[-1]
    res_csv_ad['online_version'] = folder_name

    res_csv_ad['etl_time'] = now_date_time.strftime("%Y-%m-%d %H:%M:%S")
    res_csv_ad[['deviceid', "1_label", 'label', "activate_date", "predict_date", 'online_version', "etl_time"]].to_csv(
        XNHD_save_path,
        index=False)


def save_virtual_callback(save_folder, save_path, res_csv_ad):
    XNHD_save_path = "/".join([save_folder, save_path])
    XNHD_save_path = "./" + XNHD_save_path
    now_date_time = datetime.datetime.now()
    res_csv_ad['etl_time'] = now_date_time.strftime("%Y-%m-%d %H:%M:%S")
    res_csv_ad[['deviceid', "1_label", 'label', "model_days", "activate_date", "predict_date", "etl_time"]].to_csv(
        XNHD_save_path,
        index=False)


def save_adgroup_orders_to_hive(hive_engine, res_csv_ad, hive_table_name, is_offline=False):
    # 广告粒度的预测结果
    res_csv_ad = res_csv_ad.groupby(
        ['activate_date', 'advertiserid', 'adgroupid', 'dim_ad_channel_name', 'model_days', 'predict_date'])[
        ["1_label"]].sum().reset_index()

    if is_offline == False:
        print("===========广告粒度的预测结果开始写入表 " + hive_table_name + '============')
        table_name = hive_table_name.split(".")[1]
        # 存入hive表！！！
        res_csv_ad.to_sql(table_name, con=hive_engine, index=False, if_exists='append',
                          method='multi', chunksize=1000)
        print('===========广告粒度的预测结果写入 ' + table_name + '完毕！！！============')
    else:
        print('===========广告粒度的预测结果离线结果展示============')
        print(res_csv_ad)


def save_model_inf_to_hive_v2(hive_engine, model, hive_table_name, valid_cal_index_res, today, folder, yanzhengji_auc,
                              model_days,
                              is_offline=False):
    maxthresh = max_index_threshold(valid_cal_index_res)
    model_INF_res = {}
    # 保存模型地址
    model_INF_res['predict_date'] = [today.strftime('%Y-%m-%d')]
    model_INF_res['install_date'] = [date2str(today + datetime.timedelta(days=-model_days))]
    model_INF_res['valid_auc'] = [str(round(yanzhengji_auc, 4))]
    model_file_name = today.strftime('%Y-%m-%d') + "_day" + str(model_days) + "_model.pkl"
    model_path = "/".join([folder, model_file_name])
    model_path = "./" + model_path
    save_obj(model, model_path)

    model_INF_res['model_save_path'] = [model_path]

    # 添加三个列
    model_INF_res['max_f1_threshold'] = maxthresh['max_f1_threshold']
    model_INF_res['max_f1_recall'] = valid_cal_index_res[model_INF_res['max_f1_threshold']]['recall']
    model_INF_res['max_f1_precision'] = valid_cal_index_res[model_INF_res['max_f1_threshold']]['precision']

    # 根据路径， 分析该模型是第几代
    folder = os.getcwd().split('/')[-1]
    try:
        file_name_list = folder.split('_')[:2]
        suffix = int(file_name_list[1][1:]) - 1
        file_name_list[1] = 'v' + str(suffix)
        file_name = "_".join(file_name_list)
    except:
        file_name = folder
    model_INF_res['online_version'] = file_name
    now_date_time = datetime.datetime.now()
    model_INF_res['etl_time'] = now_date_time.strftime("%Y-%m-%d %H:%M:%S")
    # 增加 三个指标最大值对应的 阈值
    # 保存其他信息
    model_df = pd.DataFrame(model_INF_res)
    print(model_df)
    if is_offline == False:
        print('===========模型的结果开始写入 ' + hive_table_name + '！！！============')
        table_name = hive_table_name.split(".")[1]
        # 存入hive表！！！
        model_df.to_sql(table_name, con=hive_engine, index=False, if_exists='append',
                        method='multi', chunksize=1000)
        print('===========模型的结果写入' + table_name + ' 完毕！！！============')
    else:
        print('===========模型的结果离线结果展示============')
        print(model_df)


def save_model_inf_to_hive(hive_engine, model, hive_table_name, valid_cal_index_res, today, folder, yanzhengji_auc,
                           model_days,
                           is_offline=False):
    maxthresh = max_index_threshold(valid_cal_index_res)
    model_INF_res = {}
    # 保存模型地址
    model_INF_res['predict_date'] = [today.strftime('%Y-%m-%d')]
    model_INF_res['model_days'] = ['day' + str(model_days)]
    model_INF_res['valid_auc'] = [str(round(yanzhengji_auc, 4))]
    model_file_name = today.strftime('%Y-%m-%d') + "_day" + str(model_days) + "_model.pkl"
    model_path = "/".join([folder, model_file_name])
    model_path = "./" + model_path
    save_obj(model, model_path)

    model_INF_res['model_save_path'] = [model_path]

    # 添加三个列
    model_INF_res['max_f1_threshold'] = maxthresh['max_f1_threshold']
    model_INF_res['max_f1_recall'] = valid_cal_index_res[model_INF_res['max_f1_threshold']]['recall']
    model_INF_res['max_f1_precision'] = valid_cal_index_res[model_INF_res['max_f1_threshold']]['precision']

    # 根据路径， 分析该模型是第几代
    folder = os.getcwd().split('/')[-1]
    try:
        file_name_list = folder.split('_')[:2]
        suffix = int(file_name_list[1][1:]) - 1
        file_name_list[1] = 'v' + str(suffix)
        file_name = "_".join(file_name_list)
    except:
        file_name = folder
    model_INF_res['online_version'] = file_name
    now_date_time = datetime.datetime.now()
    model_INF_res['etl_time'] = now_date_time.strftime("%Y-%m-%d %H:%M:%S")
    # 增加 三个指标最大值对应的 阈值
    # 保存其他信息
    model_df = pd.DataFrame(model_INF_res)

    if is_offline == False:
        print('===========模型的结果开始写入 ' + hive_table_name + '！！！============')
        table_name = hive_table_name.split(".")[1]
        # 存入hive表！！！
        model_df.to_sql(table_name, con=hive_engine, index=False, if_exists='append',
                        method='multi', chunksize=1000)
        print('===========模型的结果写入' + table_name + ' 完毕！！！============')
    else:
        print('===========模型的结果离线结果展示============')
        print(model_df)


def feature_processing(df, feature_list, save_columns, model_days, save_file):
    numeric_features = []
    category_features = []
    suffix = "_input"
    features_operator = {}
    print("正在处理数据", end="")
    for feature in feature_list:
        # 过滤掉 缺失率过高特征
        if feature[:-len(suffix)] in save_columns:
            continue
        output_feature_name = feature
        # 保存每个特征 初始化后的算子
        features_operator[output_feature_name] = []
        # 变换算子
        transform = feature_list[feature]["transform"]
        init_param = feature_list[feature]["init_param"]
        feature_type = feature_list[feature]["feature_type"]
        param = feature_list[feature]["param"]

        # 如果是 一个元素，而且是字符串,转成list
        if type(init_param) == type("str"):
            init_param = [init_param]
            if len(init_param) == 1 and len(init_param) < len(transform):
                init_param = init_param + ["series"] * (len(transform) - 1)

        # feature 分类
        raw_col_name = feature[:-len(suffix)]
        # 如果 某个特征 因为缺失率过高需要排除，需要将其剔除。
        if feature_type == "numerical" and raw_col_name not in save_columns:
            numeric_features.append(raw_col_name)
        elif feature_type == "categorical" and raw_col_name not in save_columns:
            category_features.append(raw_col_name)

        for step, Temp_Transform in enumerate(transform):
            # 里面的param 只给 第一步处理，可能后续 会有每一步都需要参数，目前没有。
            if step == 0:
                if init_param[step] == "df":
                    # 从类实例化对象
                    param['data'] = df.copy()
                    operator = Temp_Transform()
                    # 传入 参数对算子进行 call
                    df = operator(**param)
                    features_operator[output_feature_name].append(copy.deepcopy(operator))
                elif init_param[step] == "series":
                    # series 参数不用传入call，直接用参数feature 初始化 算子
                    raw_series = df[param['features_name'][0]].copy()
                    # raw_series = df.loc[:, param['features_name'][0]]

                    param['data'] = raw_series
                    operator = Temp_Transform()
                    df[output_feature_name] = operator(**param)
                    features_operator[output_feature_name].append(copy.deepcopy(operator))
                if "days_gap_" in output_feature_name:
                    df = date_to_longdays([output_feature_name], df.copy(), "none", model_days)

            else:
                if init_param[step] == "series":
                    # 除了第一步，后续操作都是在output_feature_name 列上进行处理
                    raw_series = df[output_feature_name].copy()
                    param['data'] = raw_series
                    operator = Temp_Transform()
                    # call
                    df[output_feature_name] = operator(**param)
                    features_operator[output_feature_name].append(copy.deepcopy(operator))
                else:
                    print("第二步目前没有 df，报错！---")
                    break

    # 为了减少 代码改动的篇幅过大， 返回一个独立的 模型训练使用的 dataframe

    data = pd.DataFrame()

    for col in df.columns.values:
        if suffix in col and col[:-len(suffix)] not in save_columns:
            data[col[:-len(suffix)]] = df[col]

    inpu_cols = list(data.columns.values)

    # 除了保存模型输入的特征外，还需要保存deviceid，adgroupid等需要输出表的列。
    for ef in save_columns:
        if ef in df.columns and ef not in data.columns.values:
            data[ef] = df[ef]

    # 保存 训练集的特征算子
    try:
        features_op_file = df['activate_date'].max() + "_day" + str(model_days) + "_features_operator.pkl"
    except:
        features_op_file = date2str(df['activate_date'].max()) + "_day" + str(model_days) + "_features_operator.pkl"

    FEATURES_OPERATOR_PATH = "/".join([save_file, features_op_file])
    print("正在将该天 【特征处理算子】 保存至", FEATURES_OPERATOR_PATH)
    save_obj(features_operator, FEATURES_OPERATOR_PATH)

    return data, inpu_cols, numeric_features, category_features, features_operator


# test_date 预测集日期，我们采样的正样本，主要是在训练集和测试集中间gap的7天里进行采样，至于取多少天可作为一个参数。
def sampling_recent_days_pos_samples(samples, test_date, days):
    if type(test_date) == type('str'):
        test_date = str2date(test_date)
    sample_date_left = date2str(test_date + datetime.timedelta(days=-days + 1))
    sample_date_right = date2str(test_date + datetime.timedelta(days=-1))

    res = samples[
        (samples["activate"] >= sample_date_left) & ((samples["activate"] <= sample_date_right))].copy().reset_index(
        drop=True)
    res = res[res['label'] == 1].copy().reset_index(drop=True)

    res = res[res['first_order_date'] < date2str(test_date)].copy().reset_index(drop=True)

    return res


# T将数据处理逻辑，对应的不同features 存入一个 dict，  同时把这个devicied 的结果单独弄好！
def feature_processing_for_TESTDATA(df, feature_list, save_columns, model_days, features_operator):
    numeric_features = []
    category_features = []
    suffix = "_input"
    for feature in feature_list:
        # 读取输出变换后的列名
        if feature[:-len(suffix)] in save_columns:
            continue
        output_feature_name = feature
        # 变换算子
        transform = feature_list[feature]["transform"]
        init_param = feature_list[feature]["init_param"]
        feature_type = feature_list[feature]["feature_type"]
        param = feature_list[feature]["param"]

        # 如果是 一个元素，而且是字符串,转成list
        if type(init_param) == type("str"):
            init_param = [init_param]
            if len(init_param) == 1 and len(init_param) < len(transform):
                init_param = init_param + ["series"] * (len(transform) - 1)

        # feature 分类
        raw_col_name = feature[:-len(suffix)]
        if feature_type == "numerical" and raw_col_name not in save_columns:
            numeric_features.append(raw_col_name)
        elif feature_type == "categorical" and raw_col_name not in save_columns:
            category_features.append(raw_col_name)

        operators = features_operator[output_feature_name]
        for step, Temp_Transform in enumerate(transform):
            # 里面的param 只给 第一步处理，可能后续 会有每一步都需要参数，目前没有。
            if step == 0:
                if init_param[step] == "df":
                    # 从类实例化对象
                    param['data'] = df
                    operator = operators[step]
                    # 传入 参数对算子进行 call
                    df = operator(**param)
                elif init_param[step] == "series":
                    # series 参数不用传入call，直接用参数feature 初始化 算子
                    raw_series = df[param['features_name'][0]]
                    param['data'] = raw_series
                    operator = operators[step]
                    df[output_feature_name] = operator(**param)
                if "days_gap_" in output_feature_name:
                    df = date_to_longdays([output_feature_name], df, "none", model_days)

            else:
                if init_param[step] == "series":
                    # 除了第一步，后续操作都是在output_feature_name 列上进行处理
                    raw_series = df[output_feature_name]
                    param['data'] = raw_series
                    operator = operators[step]
                    # call
                    df[output_feature_name] = operator(**param)
                else:
                    print("第二步目前没有 df，报错！---")
                    break

    # 为了减少 代码改动的篇幅过大， 返回一个独立的 模型训练使用的 dataframe

    data = pd.DataFrame()

    for col in df.columns.values:
        if suffix in col and col[:-len(suffix)] not in save_columns:
            data[col[:-len(suffix)]] = df[col]

    inpu_cols = list(data.columns.values)

    # 除了保存模型输入的特征外，还需要保存deviceid，adgroupid等需要输出表的列。
    for ef in save_columns:
        if ef in df.columns and ef not in data.columns.values:
            data[ef] = df[ef]

    return data, inpu_cols, numeric_features, category_features


import seaborn as sns
import matplotlib.pyplot as plt


def plot_features_compare(datas, features, cols):
    if type(datas) != list:
        datas = list(datas)

    if type(features) != list:
        features = list(features)

    if type(cols) != list:
        cols = list(cols)

    col_data = []
    label_col = []

    for i in range(len(datas)):
        col_data += list(datas[i][features[i]].values)
        label_col += [cols[i]] * len(list(datas[i][features[i]].values))

    combine_data = pd.DataFrame({"label": label_col, features[0]: col_data})
    print(features[0])
    plt.figure(dpi=100, figsize=(10, 8))
    sns.boxplot(data=combine_data, x='label', y=features[0])
    plt.show()


def plot_feature_distribution(dataset, feature, name, top=10):
    from collections import Counter
    city2num = Counter(list(dataset[feature].values))

    cs2num = sorted(city2num.items(), key=lambda x: x[1], reverse=True)
    citys = []
    for temp in cs2num:
        citys.append(temp[0])

    data = []
    show_labels = []
    for i in range(top):
        data.append(cs2num[i][1] / len(dataset))
        show_labels.append(cs2num[i][0])

    import matplotlib.pyplot as plt
    import matplotlib

    plt.figure(dpi=100, figsize=(10, 4))
    plt.bar(range(len(data)), data)
    plt.xticks(range(len(data)), show_labels)
    plt.xlabel(name)
    plt.show()


from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


## 传入是dateframe， 需要有2个字段：pred_score, label 用于计算f1，recall，Precision，accuracy
def calculate_f1(sample_1, pred_score_col = "1_label", label_col = 'label'):

    if pred_score_col in sample_1.columns.values:
        sample_1.rename(columns={pred_score_col: "pred_score"}, inplace=True)

    for i in np.arange(0.01, 0.31, 0.01):
        col = 'yuzhi_' + str(int(i * 100))
        sample_1[col] = sample_1.apply(lambda a: 1 if a['pred_score'] >= i else 0, axis=1)
    sample_1[label_col] = sample_1[label_col].astype(int)

    for i in np.arange(0.01, 0.31, 0.01):
        key = 'yuzhi_' + str(int(i * 100))
        print(round(accuracy_score(sample_1[label_col].values, sample_1[key].values), 4),
              round(precision_score(sample_1[label_col].values, sample_1[key].values), 4),
              round(recall_score(sample_1[label_col].values, sample_1[key].values), 4),
              round(f1_score(sample_1[label_col], sample_1[key].values), 4))


def max_calculate_f1(sample_1, pred_score_col="1_label", label_col='label'):
    if pred_score_col in sample_1.columns.values:
        sample_1.rename(columns={pred_score_col: "pred_score"}, inplace=True)

    res = [0,0,0,0]
    for i in np.arange(0.01, 0.61, 0.01):
        col = 'yuzhi_' + str(int(i * 100))
        sample_1[col] = sample_1.apply(lambda a: 1 if a['pred_score'] >= i else 0, axis=1)
    sample_1[label_col] = sample_1[label_col].astype(int)

    for i in np.arange(0.01, 0.61, 0.01):
        key = 'yuzhi_' + str(int(i * 100))
        a1 = round(accuracy_score(sample_1[label_col].values, sample_1[key].values), 4)
        a2 = round(precision_score(sample_1[label_col].values, sample_1[key].values), 4)
        a3 = round(recall_score(sample_1[label_col].values, sample_1[key].values), 4)
        a4 = round(f1_score(sample_1[label_col], sample_1[key].values), 4)
        if a4 > res[3]:
            res = [round(i,2),a2,a3,a4]

    return res



# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 判断是否是节假日
def Judge_is_Festival(test_date):
    festivals = ['01-01', '11-11', '12-12', '10-01', '08-18', '05-01', '06-18', '01-21', '04-05', ]
    # 如果是节假日或者节假日后三天，则返回True
    for delta in range(0, 3):
        tmp_date = date2str(str2date(test_date) + datetime.timedelta(days=-delta))
        if tmp_date[len('2022') + 1:] in festivals:
            return True
    return False



# 类别特征交叉（交叉方式 多个类别特征合成一个）
def category_feature_crossing(features:list, df:pd.DataFrame):

    cross_feature_name = "_".join(features)

    for feature in features:
        if cross_feature_name not in df.columns.values:
            df[cross_feature_name] = df[feature]
        else:
            df[cross_feature_name] += df[feature]

    return df, [cross_feature_name]


def res_affect_to_csv(res_affect, ):
    res_dict = {}
    res_dict['test_date'] = list(res_affect.keys())
    res_dict['auc'] = []
    res_dict['gap'] = []
    res_dict['f1'] =[]
    for i in res_affect:
        res_dict['auc'].append(res_affect[i][0])
        res_dict['gap'].append(res_affect[i][1])
        res_dict['f1'].append(res_affect[i][2])
    res = pd.DataFrame(res_dict)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    res.to_csv(now + "experiment.csv")
    print(res)



import lightgbm as lgb
def plot_lightGBM_tree(model_path,tree_index):
    lgb_model = load_obj(model_path)
    fig = plt.figure(figsize=(10,4))
    ax = fig.subplots()
    lgb.plot_tree(lgb_model[0], tree_index=tree_index, ax=ax)
    plt.show()


def save_virtual_callback_offline(save_folder, save_path, res_csv_ad, online_version = ""):
    XNHD_save_path = "/".join([save_folder, save_path])
    XNHD_save_path = "./" + XNHD_save_path
    now_date_time = datetime.datetime.now()

    res_csv_ad['online_version'] = online_version


    res_csv_ad['etl_time'] = now_date_time.strftime("%Y-%m-%d %H:%M:%S")
    res_csv_ad[['deviceid', "1_label", "activate_date", "predict_date",'online_version', "etl_time"]].to_csv(
        XNHD_save_path,
        header=None,
        index=False)



def train_pred_offline(startdate, enddate, validate_date, sample_day1, input_features, category_features, model_days,
               is_offline=False,folder = "mid_results"):
    # deviceid 返回值
    res_csv_ad = None
    train_data = sample_day1[(sample_day1['activate_date'] >= startdate) & (
            sample_day1['activate_date'] <= enddate)]
    print("训练的日期包括: ", np.unique(train_data['activate_date']))
    validate_data = sample_day1[(sample_day1['activate_date'] == validate_date)]

    # 10折交叉验证 保持结果相对稳定
    split = 10
    kf = KFold(n_splits=split, shuffle=True, random_state=42)
    train_X = train_data[input_features]
    train_y = train_data['label']

    every_fold_auc = 0.0
    every_fold_loss = 0.0
    today = str2date(validate_date)
    valid_orders = []
    valid_preds = []
    valid_gap = 0.0
    valid_cal_index_res = {}
    # n个模型结果融合
    model_set = []
    for train_index, val_index in kf.split(train_X):
        model = LGBMClassifier(boosting_type='gbdt',
                               num_leaves=31, max_depth=3,
                               learning_rate=0.06, n_estimators=10000,
                               subsample_for_bin=200000, objective=None,
                               class_weight=None, min_split_gain=0.0,
                               min_child_weight=1,
                               min_child_samples=20, subsample=0.8, subsample_freq=1,
                               colsample_bytree=0.9,
                               reg_alpha=0.0, reg_lambda=0.0, random_state=42,
                               n_jobs=31, silent=True, verbose=-1)

        X_train, y_train = train_X.iloc[train_index], train_y.iloc[train_index]
        X_val, y_val = train_X.iloc[val_index], train_y.iloc[val_index]
        model.fit(X_train, y_train, eval_set=[(X_val, y_val)], categorical_feature=category_features, eval_metric="auc",
                  verbose=-1,
                  early_stopping_rounds=50)

        # 增加 验证集的f1_score, recall_score, recall 三个指标
        val_pred_score = model.predict_proba(X_val)[:, 1]
        temp_calculate = pd.DataFrame({"pred_score": val_pred_score, "label": y_val})
        valid_cal_index_res = calculate_indexs(temp_calculate, valid_cal_index_res, split)
        val_pred = val_pred_score.sum()

        valid_preds.append(val_pred)
        valid_orders.append(sum(y_val))
        try:
            valid_gap += abs((valid_preds[-1] - valid_orders[-1]) / valid_orders[-1])
        except:
            print("")

        every_fold_auc += model.best_score_['valid_0']['auc']
        every_fold_loss += model.best_score_['valid_0']['binary_logloss']
        import copy
        model_set.append(copy.deepcopy(model))

    valid_avg_pred = valid_gap / split
    yanzhengji_auc = every_fold_auc / split
    yanzhengji_loss = every_fold_loss / split

    # 预测测试集
    res_csv_ad = Guiyin_cv(model_set, res_csv_ad, validate_data, input_features,
                           ['deviceid', 'activate_date',  'label', 'pred_score'],
                           model_days)

    print("============================模型的结果明细如下====================================")
    print("验证集的auc:  ", yanzhengji_auc)
    print("验证集的loss:  ", yanzhengji_loss)
    print("测试集预测的7日下单数（不包含激活当日的订单）", res_csv_ad['1_label'].sum())

    # 虚拟回调保存
    # 保存每一个设备预测的结果，供虚拟回调使用 ['deviceid', "1_label", "model_days", "activate_date", "predict_date"]

    un_time = today.strftime("%Y-%m-%d")
    file_name = "day1res_adgroup_pred_score_GBM_" + un_time + ".csv"
    save_virtual_callback(folder, file_name, res_csv_ad)

    # 保存模型
    model_file_name = today.strftime('%Y-%m-%d') + "_day" + str(model_days) + "_model.pkl"
    model_path = "/".join([folder, model_file_name])
    model_path = "./" + model_path
    save_obj(model_set, model_path)

    true_labels = sum(validate_data['label'])
    pred_labels = res_csv_ad['1_label'].sum()

    day_gap = (pred_labels - true_labels) / true_labels
    print("test_gap: ", day_gap)

    y_test = validate_data['label'].values
    y_pred = model.predict_proba(validate_data[input_features].values)[:, 1]
    test_auc = round(roc_auc_score(y_score=y_pred, y_true=y_test), 4)

    # 生成特征重要度
    generate_feature_importance(model,
                                "./" + folder + "/day1features_importance_GBM_" + today.strftime("%Y-%m-%d") + ".csv",
                                input_features)

    auc_gap = [test_auc, day_gap]
    print("test_auc: ", test_auc)

    print("F1：", max_calculate_f1(res_csv_ad, "1_label", 'label'))

    return model_set, auc_gap


class AP_dataset:
    def __init__(self, samples, config, categorical_feature_num = -1):
        self.categorical_feature_num = categorical_feature_num
        self.features = self.get_feature_names(config)
        self.categorical_features = self.features[:self.categorical_feature_num]
        # ttt = samples['dense_vector'].values[0]
        # samples['dense_vector'] = samples['dense_vector'].str.replace('null', "float('nan')").apply(lambda x: eval[x]['values'])

        samples['dense_vector'] = samples['dense_vector'].apply(self.process_string_vector)
        samples[self.features] = pd.DataFrame(samples['dense_vector'].to_list(), index=samples.index)

        self.dataset = samples


    def get_feature_names(self, config):
        features = config['default']
        res = []
        for i in features:
            res.append(i['name'])
        return res

    def process_string_vector(self, string: str):
        string = string.replace("null","float('nan')")
        string = string.replace("NaN", "float('nan')")
        values = eval(string)
        if "values" not in values:
            return values
        values = eval(string)['values']
        return values

    def get_datasets(self):
        return self.dataset

    def __getitem__(self, index):
        return self.dataset[index]

    def get_features(self):
        return self.features


    
class AP_dataset2:
    def __init__(self, samples, config, categorical_feature_num = -1):
        self.categorical_feature_num = categorical_feature_num
        self.features = self.get_feature_names(config)
        self.categorical_features = self.features[:self.categorical_feature_num]
        # ttt = samples['dense_vector'].values[0]
        # samples['dense_vector'] = samples['dense_vector'].str.replace('null', "float('nan')").apply(lambda x: eval[x]['values'])

        samples['dense_vector'] = samples['dense_vector'].apply(self.process_string_vector)

        self.dataset = samples


    def get_feature_names(self, config):
        features = config['default']
        res = []
        for i in features:
            res.append(i['name'])
        return res

    def process_string_vector(self, string: str):
        string = string.replace("null","float('nan')")
        string = string.replace("NaN", "float('nan')")
        values = eval(string)
        if "values" not in values:
            return values
        values = eval(string)['values']
        return values

    def get_datasets(self):
        return self.dataset

    def __getitem__(self, index):
        return self.dataset[index]

    def get_features(self):
        return self.features
    

#################################gauc gf1 ################################################################

class RES_ANALYSIS:
    def __init__(self, samples, pred_col='predict_score', label_col='label', group_col = "group_col"):
        self.res = samples
        self.pred_col = pred_col
        self.label_col = label_col
        self.dates = self.get_dates_set()



    def get_dates_set(self):
        dates = np.unique(self.res['activate_date'].values)
        dates.sort()
        return dates


    def calculate_res(self, sample_1):
        sample_1 = sample_1

        y_true = sample_1[self.label_col]
        y_pred = sample_1[self.pred_col]
        test_auc = round(roc_auc_score(y_score=y_pred, y_true=y_true), 4)

        resl = [0, 0, 0, 0]
        for i in np.arange(0.01, 0.31, 0.01):
            col = 'yuzhi_' + str(int(i * 100))
            sample_1[col] = sample_1.apply(lambda a: 1 if a[self.pred_col] >= i else 0, axis=1)
        sample_1[self.label_col] = sample_1[self.label_col].astype(int)

        for i in np.arange(0.01, 0.31, 0.01):
            key = 'yuzhi_' + str(int(i * 100))
            a1 = round(accuracy_score(sample_1[self.label_col].values, sample_1[key].values), 4)
            a2 = round(precision_score(sample_1[self.label_col].values, sample_1[key].values), 4)
            a3 = round(recall_score(sample_1[self.label_col].values, sample_1[key].values), 4)
            a4 = round(f1_score(sample_1[self.label_col], sample_1[key].values), 4)
            if a4 >= resl[3]:
                resl = [round(i, 2), a2, a3, a4]
        res = pd.DataFrame({'f1': [resl], 'auc': [test_auc]})

        return res

    def get_date_res(self):
        res = None
        for date in self.dates:
            tp_res = self.calculate_res(self.res[self.res['activate_date'] == date])
            tp_res['date'] = date
            if res is None:
                res = tp_res
            else:
                res = pd.concat([res, tp_res], axis=0)

        return res.reset_index()

    def get_auc_f1(self):
        return self.calculate_res(self.res)


    def get_group_res(self, group_col):
        res = None
        for date in self.dates:
            tp_res = self.res[self.res['activate_date'] == date]
            tp_res = tp_res.groupby( group_col).apply( self.calculate_res)
            tp_res['date'] = date
            if res is None:
                res = tp_res
            else:
                res = pd.concat([res, tp_res], axis=0)

        return res.reset_index()




def read_json_config(filename):
    with open('featurelist383.json', 'r', encoding='utf-8') as file:
        # 使用json.load()函数读取文件内容并将其转换为字典
        config = json.load(file)
    return config


import os
import psutil
def get_memory_usage():
    process = psutil.Process(os.getpid())
    mem_info = process.memory_info()
    mem_in_MB = mem_info.rss / (1024 * 1024)
    print(f"当前Jupyter占用的内存为：{mem_in_MB:.2f} MB")
    return f"当前Jupyter占用的内存为：{mem_in_MB:.2f} MB"

def train_auto_ml(train_data,test_data, Pred_Date, Pred_Days, save_path = 'auto_ml' ):

    from autogluon.tabular import TabularDataset, TabularPredictor
    hyperparameters = {
        'GBM': {},
        'CAT': {},
        'RF': {},
        'NN_TORCH': {},
        'FASTAI': {}

    }
    metric = 'roc_auc'
    predictor = TabularPredictor(label="label", eval_metric=metric, path=save_path).fit(train_data,
                                                                                        hyperparameters=hyperparameters,
                                                                                        holdout_frac=0.1)







# ---------------------------------------------------空窗期样本加入--------------------------------------------------------------
# ---------------------------------------------------空窗期样本加入--------------------------------------------------------------
def count_decision_days(samples):
    samples['decision_days'] = samples['first_order_date'].apply(lambda x: str2date(x)) - samples[
        'activate_date'].apply(lambda x: str2date(x))
    samples['decision_days'] = samples['decision_days'].apply(lambda x: x.days)

    # 未下单的用户置为空
    samples[samples['decision_days'] < 0] = None
    return samples['decision_days']


def count_orderX_order7(train_data, i):
    sample_weight_pos_samples = {}
    print("=======================================计算 回流系数 ======================================================")
    print("已回流的正样本个数%d, 决策周期为7时的正样本数%d" % (
    (train_data['label'] == 1).sum(), (train_data['decision_days'] <= 6).sum()))
    print(
        f"""近三天的预估7回流数：{(train_data['label'] * train_data['sample_weight']).sum()}, 决策周期<={i}的label数{(train_data['decision_days'] <= i).sum()}""")

    sample_weight_pos_samples['pos_weight_in' + str(i + 1)] = (train_data['label'] * train_data[
        'sample_weight']).sum() / (train_data['decision_days'] <= i).sum()
    print("=======================================计算完成 ======================================================")
    return sample_weight_pos_samples['pos_weight_in' + str(i + 1)]


# 3  空窗期样本带权采样，https://wiki.tuhu.cn/pages/viewpage.action?pageId=340260725 样本优化，充分利用空窗期样本，使其更接近预测集下单期望。
def sampling_recent_days_samples(samples, test_date, slide_window=3, is_offline=False):
    if type(test_date) == type('str'):
        test_date = str2date(test_date)
    # 根据预测集的日期，计算出空窗期的7天时间范围(空窗期其实只有5天)  1（训练集最后一天）  2,3,4,5,6,    （test日期）7
    #                                                                     order_6,order_5,...

    # 初始化所有样本的权重为1
    samples['sample_weight'] = 1.0

    # 6天的窗口期
    date_left = test_date + datetime.timedelta(days=-6)
    date_right = test_date + datetime.timedelta(days=-1)

    left_window =  test_date + datetime.timedelta(days=-6)
    right_window = test_date + datetime.timedelta(days=-1)

    # 计算下单犹豫时间
    samples['decision_days'] = count_decision_days(samples.copy())

    sample_weight_pos_samples = {}
    i = 5
    while date_left <= date_right:

        # 用最近3天的回流率滑动比值 还原窗口期7日回流率
        tp_date_substract_1day = date2str(date_left + datetime.timedelta(days=-1))
        tp_date_substract_3day = date2str(date_left + datetime.timedelta(days=-slide_window))
        tp_date = date2str(date_left)

        sample_weight_pos_samples['pos_weight_in' + str(i + 1)] = count_orderX_order7(samples[(samples[
                                                                                                   'activate_date'] <= tp_date_substract_1day) & (
                                                                                                      samples[
                                                                                                          'activate_date'] >= tp_date_substract_3day)],
                                                                                      i)

        print("空窗日期%s，即回流了%d天的正样本权重为：%s" % (
        tp_date, i + 1, sample_weight_pos_samples['pos_weight_in' + str(i + 1)]))

        # 增加正样本的权重
        samples.loc[(samples["activate_date"] == tp_date) & (samples['decision_days'] <= i), 'sample_weight'] = \
            sample_weight_pos_samples['pos_weight_in' + str(i + 1)]
        print("空窗日期为%s，七日回流数为%d" % (tp_date, samples[(samples["activate_date"] == tp_date)]['label'].sum()))

        # 如果是离线，需要对未满i天的label置为0
        if is_offline == True:
            samples.loc[(samples["activate_date"] == tp_date) & (samples['decision_days'] > i), 'label'] = 0
            print("离线试验下%s，已回流数 %d" % (tp_date, samples[(samples["activate_date"] == tp_date)]['label'].sum()))

        a = len(samples[(samples["activate_date"] == tp_date)])
        b = samples[(samples["activate_date"] == tp_date)]['label'].sum()
        weight = sample_weight_pos_samples['pos_weight_in' + str(i + 1)]
        # 负样本的权重也要降低  weight=   （激活数 - 已回流数*weight ）/ （激活数 - 已回流数）

        samples.loc[(samples["activate_date"] == tp_date) & (samples['label'] == 0), 'sample_weight'] = (
                                                                                                                a - b * weight) / (
                                                                                                                a - b)


        date_left += datetime.timedelta(days=1)
        i -= 1

    return samples[(samples['activate_date'] >= date2str(left_window)) & (samples['activate_date'] <= date2str(right_window))]


# -----------------------------------PRED sample score-----------------------------------
def pred_score_by_lgb(model_set, res_df, test_data, input_features, columns):

    if type(res_df) == type(None):
        res_df = pd.DataFrame(columns=columns)
    res_dict = {}
    for col in columns:
        res_dict[col] = []

    pred_score = None
    test_data[columns[-1]] = 0
    for model in model_set:
        test_data[columns[-1]] += model.predict_proba(test_data[input_features])[:, 1]
    test_data[columns[-1]] = test_data[columns[-1]] / len(model_set)

    print("pred_lgb_auc: ", roc_auc_score(y_score=test_data[columns[-1]].values,y_true=test_data['label'].values))

    # 如果日期是 日期类型，转成字符串固定格式，年月日。
    if test_data.dtypes['activate_date'] == 'datetime64[ns]':
        test_data['activate_date'] = test_data['activate_date'].apply(lambda x: x.strftime("%Y-%m-%d"))


    return test_data[columns]





def train_pred_real_time(startdate, enddate, validate_date, sample_day1, input_features, category_features,
                         save_columns, label_col,
                         folder="mid_results"):
    # deviceid 返回值
    res_csv_ad = None
    train_data = sample_day1[(sample_day1['activate_date'] >= startdate) & (
            sample_day1['activate_date'] <= enddate)]
    print("训练的日期包括: ", np.unique(train_data['activate_date']))

    validate_data = sample_day1[(sample_day1['activate_date'] == validate_date)]
    print(f"训练集的数量：{len(train_data)}, 测试集在数量:{len(validate_data)}")

    # 10折交叉验证 保持结果相对稳定
    split = 10
    kf = KFold(n_splits=split, shuffle=True, random_state=42)
    train_X = train_data[input_features]
    train_y = train_data[label_col]

    every_fold_auc = 0.0
    every_fold_loss = 0.0
    today = str2date(validate_date)
    valid_orders = []
    valid_preds = []
    valid_gap = 0.0
    valid_cal_index_res = {}
    # n个模型结果融合
    model_set = []
    for train_index, val_index in kf.split(train_X):
        model = LGBMClassifier(boosting_type='gbdt',
                               num_leaves=31, max_depth=3,
                               learning_rate=0.06, n_estimators=10000,
                               subsample_for_bin=200000, objective=None,
                               class_weight=None, min_split_gain=0.0,
                               min_child_weight=1,
                               min_child_samples=20, subsample=0.8, subsample_freq=1,
                               colsample_bytree=0.9,
                               reg_alpha=0.0, reg_lambda=0.0, random_state=42,
                               n_jobs=31, silent=True, verbose=-1)

        X_train, y_train = train_X.iloc[train_index], train_y.iloc[train_index]
        X_val, y_val = train_X.iloc[val_index], train_y.iloc[val_index]
        model.fit(X_train, y_train, eval_set=[(X_val, y_val)], categorical_feature=category_features, eval_metric="auc",
                  verbose=-1,
                  early_stopping_rounds=50)

        # 增加 验证集的f1_score, recall_score, recall 三个指标
        val_pred_score = model.predict_proba(X_val)[:, 1]
        temp_calculate = pd.DataFrame({"pred_score": val_pred_score, "label": y_val})
        valid_cal_index_res = calculate_indexs(temp_calculate, valid_cal_index_res, split)
        val_pred = val_pred_score.sum()

        valid_preds.append(val_pred)
        valid_orders.append(sum(y_val))
        try:
            valid_gap += abs((valid_preds[-1] - valid_orders[-1]) / valid_orders[-1])
        except:
            print("")

        every_fold_auc += model.best_score_['valid_0']['auc']
        every_fold_loss += model.best_score_['valid_0']['binary_logloss']
        import copy
        model_set.append(copy.deepcopy(model))

    valid_avg_pred = valid_gap / split
    yanzhengji_auc = every_fold_auc / split
    yanzhengji_loss = every_fold_loss / split

    # 预测测试集
    res_csv_ad = pred_score_by_lgb(model_set, res_csv_ad, validate_data, input_features,
                                   save_columns + ['1_label']
                                   )
    print("============================模型的结果明细如下====================================")
    print("验证集的auc:  ", yanzhengji_auc)
    print("验证集的loss:  ", yanzhengji_loss)
    print("测试集预测的7日下单数（不包含激活当日的订单）", res_csv_ad['1_label'].sum())

    # 虚拟回调保存
    # 保存每一个设备预测的结果，供虚拟回调使用 ['deviceid', "1_label", "model_days", "activate_date", "predict_date"]

    un_time = today.strftime("%Y-%m-%d")
    file_name = "res_adgroup_pred_score_GBM_" + un_time + ".csv"

    res_csv_ad.to_csv(
        f"./{folder}/{file_name}"
        , index=False)

    true_labels = sum(validate_data['label'])
    pred_labels = res_csv_ad['1_label'].sum()

    day_gap = (pred_labels - true_labels) / true_labels
    print("test_gap: ", day_gap)

    y_test = validate_data['label'].values
    y_pred = model.predict_proba(validate_data[input_features].values)[:, 1]
    test_auc = round(roc_auc_score(y_score=y_pred, y_true=y_test), 4)

    # 生成特征重要度
    generate_feature_importance(model,
                                "./" + folder + "/features_importance_GBM_" + today.strftime("%Y-%m-%d") + ".csv",
                                input_features)

    print("test_auc: ", test_auc)
    f1 = max_calculate_f1(res_csv_ad, "1_label", 'label')
    auc_gap = [test_auc, day_gap, f1]
    return model_set, auc_gap




def train_window_sample_model(startdate, enddate, validate_date, sample_day1, test_data, recent_samples, input_features,
                              category_features, save_columns, label_col,
                              folder="mid_results"):
    # deviceid 返回值
    res_csv_ad = None
    train_data = sample_day1[(sample_day1['activate_date'] >= startdate) & (
            sample_day1['activate_date'] <= enddate)]

    print("近期模型的日期包括: ", np.unique(train_data['activate_date']))
    train_data['sample_weight'] = 1.0
    recent_data = recent_samples

    validate_data = test_data
    print(f"训练集的数量：{len(train_data)}, 近期窗口样本数量{recent_data.shape[0]}, 测试集在数量:{len(validate_data)}")

    # 10折交叉验证 保持结果相对稳定
    split = 10
    kf = KFold(n_splits=split, shuffle=True, random_state=42)
    train_X = pd.concat([train_data[input_features], recent_data[input_features]], ignore_index=True)
    train_y = pd.concat([train_data[label_col], recent_data[label_col]], ignore_index=True)

    train_X_Sampleweight = pd.concat([train_data['sample_weight'], recent_data['sample_weight']], ignore_index=True)

    every_fold_auc = 0.0
    every_fold_loss = 0.0
    today = str2date(validate_date)
    valid_orders = []
    valid_preds = []
    valid_gap = 0.0
    valid_cal_index_res = {}
    # n个模型结果融合
    model_set = []
    for train_index, val_index in kf.split(train_X):
        model = LGBMClassifier(boosting_type='gbdt',
                               num_leaves=31, max_depth=3,
                               learning_rate=0.06, n_estimators=10000,
                               subsample_for_bin=200000, objective=None,
                               class_weight=None, min_split_gain=0.0,
                               min_child_weight=1,
                               min_child_samples=20, subsample=0.8, subsample_freq=1,
                               colsample_bytree=0.9,
                               reg_alpha=0.0, reg_lambda=0.0, random_state=42,
                               n_jobs=31, silent=True, verbose=-1)

        X_train, y_train = train_X.iloc[train_index], train_y.iloc[train_index]
        X_val, y_val = train_X.iloc[val_index], train_y.iloc[val_index]

        X_train_sample_weight = train_X_Sampleweight.iloc[train_index].values

        model.fit(X_train, y_train, eval_set=[(X_val, y_val)], categorical_feature=category_features, eval_metric="auc",
                  verbose=-1,
                  early_stopping_rounds=50, sample_weight=X_train_sample_weight)

        # 增加 验证集的f1_score, recall_score, recall 三个指标
        val_pred_score = model.predict_proba(X_val)[:, 1]
        temp_calculate = pd.DataFrame({"pred_score": val_pred_score, "label": y_val})
        valid_cal_index_res = calculate_indexs(temp_calculate, valid_cal_index_res, split)
        val_pred = val_pred_score.sum()

        valid_preds.append(val_pred)
        valid_orders.append(sum(y_val))
        try:
            valid_gap += abs((valid_preds[-1] - valid_orders[-1]) / valid_orders[-1])
        except:
            print("")

        every_fold_auc += model.best_score_['valid_0']['auc']
        every_fold_loss += model.best_score_['valid_0']['binary_logloss']
        import copy
        model_set.append(copy.deepcopy(model))

    valid_avg_pred = valid_gap / split
    yanzhengji_auc = every_fold_auc / split
    yanzhengji_loss = every_fold_loss / split

    # 预测测试集
    res_csv_ad = pred_score_by_lgb(model_set, res_csv_ad, validate_data, input_features,
                                   save_columns + ['1_label']
                                   )
    print("============================模型的结果明细如下====================================")
    print("验证集的auc:  ", yanzhengji_auc)
    print("验证集的loss:  ", yanzhengji_loss)
    print("测试集预测的7日下单数（不包含激活当日的订单）", res_csv_ad['1_label'].sum())

    # 虚拟回调保存
    # 保存每一个设备预测的结果，供虚拟回调使用 ['deviceid', "1_label", "model_days", "activate_date", "predict_date"]

    un_time = today.strftime("%Y-%m-%d")
    file_name = "res_adgroup_pred_score_GBM_" + un_time + ".csv"

    res_csv_ad.to_csv(
        f"./{folder}/{file_name}"
        , index=False)

    true_labels = sum(validate_data['label'])
    pred_labels = res_csv_ad['1_label'].sum()

    day_gap = (pred_labels - true_labels) / true_labels
    print("test_gap: ", day_gap)

    y_test = validate_data['label'].values
    print("test_shape: ", validate_data.shape, "  test order sum: ", true_labels, "  test predict order sum: ", pred_labels)
    # 生成特征重要度
    generate_feature_importance(model,
                                "./" + folder + "/features_importance_GBM_" + today.strftime("%Y-%m-%d") + ".csv",
                                input_features)

    f1 = max_calculate_f1(res_csv_ad, "1_label", 'label')
    auc_gap = [ day_gap, f1]
    return model_set, auc_gap


import pandas as pd


def pred_score_by_deep(model, res_df, test_data, features, label_col, columns, pred_cols = ['pred_score']):
    import torch
    device = torch.device('cpu')
    if type(res_df) == type(None):
        res_df = pd.DataFrame(columns=columns)
    res_dict = {}
    for col in columns:
        res_dict[col] = []
    model.eval()
    pred_score = None

    test_data[features] = test_data[features].apply(lambda x: (x - x.mean()) / x.std())
    test_data[features] = test_data[features].fillna(0)
    test_features = torch.tensor(test_data[features].values, dtype=torch.float32).to(device)
    test_labels = torch.tensor(test_data[label_col].values, dtype=torch.float32).to(device)

    with torch.no_grad():
        pred_score = model(test_features)

    # columns[-1] 是 pred_score
    for col in columns:
        res_dict[col] = test_data[col].values
    res_dict = pd.DataFrame(res_dict)
    pred_df = pd.DataFrame(pred_score, columns=pred_cols)
    # 如果日期是 日期类型，转成字符串固定格式，年月日。
    if res_df.dtypes['activate_date'] == 'datetime64[ns]':
        res_df['activate_date'] = res_df['activate_date'].apply(lambda x: x.strftime("%Y-%m-%d"))

    return pd.concat([res_dict, pred_df], axis=1)



# 增加节假日判别。

from datetime import timedelta
def get_ecommerce_holidays():
    return ["2022-11-11","2022-06-18", "2022-12-12","2023-11-11","2023-06-18", "2023-12-12","2024-11-11","2024-06-18", "2024-12-12"]
def get_nearest_holiday(date):
    from chinese_calendar import get_holidays, is_holiday
    # 获取所有的中国节假日
    holidays = get_holidays(datetime.datetime.strptime('2022-01-01', "%Y-%m-%d"), datetime.datetime.strptime('2023-12-31', "%Y-%m-%d"))

    for i in get_ecommerce_holidays():
        holidays.append(datetime.datetime.strptime(i, "%Y-%m-%d").date())
    holidays.sort()
    # 初始化最小天数差值和最近的节假日日期
    min_diff = float('inf')
    nearest_holiday = None

    # 遍历所有节假日，找到距离最近的节假日日期
    for holiday in holidays:
        diff = abs((holiday - date).days)
        if diff <= min_diff:
            min_diff = diff
            nearest_holiday = holiday
            no_abs_diff = (holiday - date).days

    return nearest_holiday, min_diff, no_abs_diff

def judge_holiday_gap(dt):
    # 示例使用
    if isinstance(dt, str):
        dt = datetime.datetime.strptime(dt, '%Y-%m-%d').date()
    elif not isinstance(dt, type(datetime.datetime)):
        dt = dt.date()
    else:
        dt = -1
    nearest_holiday, days_to_holiday, abs_daus= get_nearest_holiday(dt)

    return abs_daus

def generate_date2holiday_gap():
    all_dates = pd.date_range('2022-01-01', '2023-12-31', freq='1D')
    all_dates_strings = [date.strftime("%Y-%m-%d") for date in all_dates ]
    date2holidaygap_dict = {}
    for tp_date in all_dates_strings:
        date2holidaygap_dict[tp_date] = judge_holiday_gap(tp_date)
    return date2holidaygap_dict


def generate_7days_label(df, generate_label=[f'label_{i}' for i in range(1, 8)]):
    delay_days = list(range(1, 8))

    df['cv_days'] = (pd.to_datetime(df.first_order_date) - pd.to_datetime(df.activate_date)).apply(lambda x: x.days + 1)
    for de_day, label_name in zip(delay_days, generate_label):
        df[label_name] = 0
        df.loc[(df.cv_days <= de_day) & (df.cv_days > 0), label_name] = 1
    return df[['cv_days'] + generate_label]



import psutil

def get_pid_work_directory(pid):

    # 根据 PID 获取进程对象
    process = psutil.Process(pid)

    # 获取进程的工作目录
    working_directory = process.cwd()

    print("工作目录:", working_directory)


def get_used_mem():
    import psutil

    # 获取系统内存信息
    mem = psutil.virtual_memory()

    available_memory = mem.used
    available_memory_mb = available_memory / (1024 * 1024)
    available_memory_gb = available_memory / (1024 * 1024 * 1024)

    print(f"已用内存: {available_memory_gb:.2f} GB")


def get_avail_mem():
    import psutil
    # 获取系统内存信息
    mem = psutil.virtual_memory()

    # 获取剩余内存（以字节为单位）
    available_memory = mem.available

    # 将字节转换为更容易阅读的格式（例如，以 MB 或 GB 为单位）
    available_memory_mb = available_memory / (1024 * 1024)
    available_memory_gb = available_memory / (1024 * 1024 * 1024)
    print(f"可用内存: {available_memory_gb:.2f} GB")
    
    
    
def read_feature_json_config(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        # 使用json.load()函数读取文件内容并将其转换为字典
        config = json.load(file)
    features_true_names = []
    for i in feature_name['default']:
        features_true_names.append(i['name'])
    
    return features_true_names
    
    
    
def log_infile(file, message):
    with open(file, "a") as f:
        f.write(message) 
                
                
                
def send_mail(msg_content):
    subject = '流量模型'  + '特征异常警告'
    # 发信方的信息：发信邮箱，QQ 邮箱授权码
    from_addr = 'tangweize@tuhu.cn'
    password = 'w2TrcT3ncb79X9ki'
    # 收信方邮箱
    recievers = ['tangweize@tuhu.cn']
    # 发信服务器
    smtp_server = 'smtp.exmail.qq.com'

    msg = MIMEText(msg_content, 'plain', 'utf-8')
    # 邮件头信息
    msg['From'] = Header('读数完成')  # 发送者
    msg['Subject'] = Header(subject, 'utf-8')  # 邮件主题

    try:
        smtpobj = smtplib.SMTP_SSL(smtp_server)
        # 建立连接--qq邮箱服务和端口号（可百度查询）
        smtpobj.connect(smtp_server, 465)
        # 登录--发送者账号和口令
        smtpobj.login(from_addr, password)
        # 发送邮件
        smtpobj.sendmail(from_addr, recievers, msg.as_string())
        print("邮件发送成功")
    except smtplib.SMTPException:
        print("无法发送邮件")
    finally:
        # 关闭服务器
        smtpobj.quit()




import lightgbm as lgb

import lightgbm as lgb
import pandas as pd


def show_lgb_top_features(model_path, feature_names, topk=20, output_path='feature_importance.csv'):
    # Load the models from the file
    tmp_model = lgb.Booster(model_file=model_path)

    # Get feature importance values
    importance_values = tmp_model.feature_importance(importance_type='gain')

    # Calculate the total importance for percentage calculation
    total_importance = sum(importance_values)

    # Create a dictionary mapping feature names to their importance values
    feature_importance_dict = dict(zip(feature_names + ['is_treatment'], importance_values))

    # Sort the features by importance value in descending order
    sorted_features = sorted(feature_importance_dict.items(), key=lambda item: item[1], reverse=True)

    # Get the top k features, their importance values, and calculate their percentage
    top_features = sorted_features[:topk]
    top_features_with_percentages = [
        (feature, importance, importance / total_importance * 100)
        for feature, importance in top_features
    ]

    for feature, importance, percentage in top_features_with_percentages:
        print(f"Feature: {feature}, Importance: {importance}, Percentage: {percentage:.2f}%")

    # Create a DataFrame from the top features
    df = pd.DataFrame(top_features_with_percentages, columns=['Feature', 'Importance', 'Percentage'])

    # Save the DataFrame to a CSV file
    df.to_csv(output_path, index=False)

    return top_features_with_percentages






from sklift.viz.base import *
def plot_uplift_by_percentile1(y_true, uplift, treatment, strategy='overall',
                              kind='line', bins=10, string_percentiles=True):
    """Plot uplift score, treatment response rate and control response rate at each percentile.

    Treatment response rate ia a target mean in the treatment group.
    Control response rate is a target mean in the control group.
    Uplift score is a difference between treatment response rate and control response rate.

    Args:
        y_true (1d array-like): Correct (true) binary target values.
        uplift (1d array-like): Predicted uplift, as returned by a models.
        treatment (1d array-like): Treatment labels.
        strategy (string, ['overall', 'by_group']): Determines the calculating strategy. Default is 'overall'.

            * ``'overall'``:
                The first step is taking the first k observations of all test data ordered by uplift prediction
                (overall both groups - control and treatment) and conversions in treatment and control groups
                calculated only on them. Then the difference between these conversions is calculated.
            * ``'by_group'``:
                Separately calculates conversions in top k observations in each group (control and treatment)
                sorted by uplift predictions. Then the difference between these conversions is calculated.

        kind (string, ['line', 'bar']): The type of plot to draw. Default is 'line'.

            * ``'line'``:
                Generates a line plot.
            * ``'bar'``:
                Generates a traditional bar-style plot.

        bins (int): Determines а number of bins (and the relative percentile) in the test data. Default is 10.
        string_percentiles (bool): type of xticks: float or string to plot. Default is True (string).

    Returns:
        Object that stores computed values.
    """

    strategy_methods = ['overall', 'by_group']
    kind_methods = ['line', 'bar']

    check_consistent_length(y_true, uplift, treatment)
    check_is_binary(treatment)
    check_is_binary(y_true)
    n_samples = len(y_true)

    if strategy not in strategy_methods:
        raise ValueError(f'Response rate supports only calculating methods in {strategy_methods},'
                         f' got {strategy}.')

    if kind not in kind_methods:
        raise ValueError(f'Function supports only types of plots in {kind_methods},'
                         f' got {kind}.')

    if not isinstance(bins, int) or bins <= 0:
        raise ValueError(
            f'Bins should be positive integer. Invalid value bins: {bins}')

    if bins >= n_samples:
        raise ValueError(
            f'Number of bins = {bins} should be smaller than the length of y_true {n_samples}')

    if not isinstance(string_percentiles, bool):
        raise ValueError(f'string_percentiles flag should be bool: True or False.'
                         f' Invalid value string_percentiles: {string_percentiles}')

    df = uplift_by_percentile(y_true, uplift, treatment, strategy=strategy,
                              std=True, total=True, bins=bins, string_percentiles=False)

    percentiles = df.index[:bins].values.astype(float)

    response_rate_trmnt = df.loc[percentiles, 'response_rate_treatment'].values
    std_trmnt = df.loc[percentiles, 'std_treatment'].values

    response_rate_ctrl = df.loc[percentiles, 'response_rate_control'].values
    std_ctrl = df.loc[percentiles, 'std_control'].values

    uplift_score = df.loc[percentiles, 'uplift'].values
    std_uplift = df.loc[percentiles, 'std_uplift'].values

    uplift_weighted_avg = df.loc['total', 'uplift']

    check_consistent_length(percentiles, response_rate_trmnt,
                            response_rate_ctrl, uplift_score,
                            std_trmnt, std_ctrl, std_uplift)

    if kind == 'line':
        _, axes = plt.subplots(ncols=1, nrows=1, figsize=(8, 6))
        axes.errorbar(percentiles, response_rate_trmnt, yerr=std_trmnt,
                      linewidth=2, color='forestgreen', label='treatment\nresponse rate')
        axes.errorbar(percentiles, response_rate_ctrl, yerr=std_ctrl,
                      linewidth=2, color='orange', label='control\nresponse rate')
        axes.errorbar(percentiles, uplift_score, yerr=std_uplift,
                      linewidth=2, color='red', label='uplift')
        axes.fill_between(percentiles, response_rate_trmnt,
                          response_rate_ctrl, alpha=0.1, color='red')

        if np.amin(uplift_score) < 0:
            axes.axhline(y=0, color='black', linewidth=1)

        if string_percentiles:  # string percentiles for plotting
            percentiles_str = [f"0-{percentiles[0]:.0f}"] + \
                              [f"{percentiles[i]:.0f}-{percentiles[i + 1]:.0f}" for i in range(len(percentiles) - 1)]
            axes.set_xticks(percentiles)
            axes.set_xticklabels(percentiles_str, rotation=45, fontsize=6)
        else:
            axes.set_xticks(percentiles)

        axes.legend(loc='upper right', fontsize=8)
        axes.set_title(
            f'Uplift by percentile\nweighted average uplift = {uplift_weighted_avg:.4f}', fontsize=8)
        axes.set_xlabel('Percentile', fontsize=8)
        axes.set_ylabel(
            'Uplift = treatment response rate - control response rate', fontsize=8)
        axes.tick_params(axis='both', which='major', labelsize=6)

    else:  # kind == 'bar'
        delta = percentiles[0]
        fig, axes = plt.subplots(ncols=1, nrows=2, figsize=(8, 6), sharex=True, sharey=True)
        fig.text(0.04, 0.5, 'Uplift = treatment response rate - control response rate',
                 va='center', ha='center', rotation='vertical', fontsize=8)

        axes[1].bar(np.array(percentiles) - delta / 6, response_rate_trmnt, delta / 3,
                    yerr=std_trmnt, color='forestgreen', label='treatment\nresponse rate')
        axes[1].bar(np.array(percentiles) + delta / 6, response_rate_ctrl, delta / 3,
                    yerr=std_ctrl, color='orange', label='control\nresponse rate')
        axes[0].bar(np.array(percentiles), uplift_score, delta / 1.5,
                    yerr=std_uplift, color='red', label='uplift')

        axes[0].legend(loc='upper right', fontsize=8)
        axes[0].tick_params(axis='x', bottom=False, labelsize=6)
        axes[0].axhline(y=0, color='black', linewidth=1)
        axes[0].set_title(
            f'Uplift by percentile\nweighted average uplift = {uplift_weighted_avg:.4f}', fontsize=8)

        if string_percentiles:  # string percentiles for plotting
            percentiles_str = [f"0-{percentiles[0]:.0f}"] + \
                              [f"{percentiles[I]:.0f}-{percentiles[I + 1]:.0f}" for I in range(len(percentiles) - 1)]
            axes[1].set_xticks(percentiles)
            axes[1].set_xticklabels(percentiles_str, rotation=45, fontsize=6)

        else:
            axes[1].set_xticks(percentiles)

        axes[1].legend(loc='upper right', fontsize=8)
        axes[1].axhline(y=0, color='black', linewidth=1)
        axes[1].set_xlabel('Percentile', fontsize=8)
        axes[1].set_title('Response rate by percentile', fontsize=8)

    return axes




# 计算统计信息 输入df， features：list， 输出  每个feature 对应的 大于0的占比、平均值、中位数
def cal_culate_feature_inf(df, feature_names):
    stats = []
    for feature in feature_names:
        non_zero_count = (df[feature] > 0).sum()
        total_count = df[feature].notna().sum()
        non_zero_rate = non_zero_count / total_count if total_count != 0 else 0
        mean_value = df[feature].mean()
        median_value = df[feature].median()
        stats.append({
            'feature': feature,
            'non_zero_rate': non_zero_rate,
            'mean': mean_value,
            'median': median_value
        })

    # 转换为 DataFrame 并展示
    stats_df = pd.DataFrame(stats)
    return stats_df
    
    
    
def plot_bias(test_data, treatment_col = 'discount_amt'):
    test_data = test_data.copy()
    treatment_values = sorted(test_data[treatment_col].unique())
    
    for v  in treatment_values:
        if v == 0.0:
            continue
        uplift_name = "uplift_" + str(v)
        plot_df = pd.concat([test_data[test_data[treatment_col] == 0.0],test_data[test_data[treatment_col] == v]], ignore_index=True)
        plot_df['w'] = plot_df[treatment_col].apply(lambda x: 0 if x==0.0 else 1)
        axes = plot_uplift_by_percentile1(plot_df['label'], plot_df[uplift_name], plot_df['w'], strategy='overall', bins=10, kind='bar',string_percentiles=True)     
        # 调整字体大小



def evaulate_p_label_in_multi_treatment(tmp_model, test_data, base_indexs,model_select = "cat", treatment_col = 'treatment_col'):
    treatment_values = sorted(test_data[treatment_col].unique())
    all_feature = base_indexs + [(test_data.dense_vector.iloc[0].shape[0] - 1)]

    if model_select == "cat":
        test_data['predict_score'] = tmp_model.predict_proba(
            (np.vstack(test_data.dense_vector.values)[:, all_feature]))[:, 1]
    elif model_select == "lgb":
        test_data['predict_score'] = tmp_model.predict(
            (np.vstack(test_data.dense_vector.values)[:, all_feature]))

    print("test_auc:  ", roc_auc_score(y_true=test_data.label, y_score=test_data.predict_score))
    for v  in treatment_values:
        p_treat_name = "p_treatment_" + str(v)
        fill_v = np.full((test_data.shape[0], 1),v)
        if model_select ==  "cat":
            test_data[p_treat_name] = tmp_model.predict_proba(np.hstack((np.vstack(test_data.dense_vector.values)[:,base_indexs], fill_v)))[:,1]
        elif model_select ==  "lgb":
            test_data[p_treat_name] = tmp_model.predict(
                np.hstack((np.vstack(test_data.dense_vector.values)[:, base_indexs], fill_v)))

        print(f"treatment: {v}, shape: {test_data[p_treat_name].shape},  p_score_avg: {test_data[p_treat_name].mean()} ")
    return test_data


def calculate_uplift(test_data, treatment_col = 'treatment_col'):
    treatment_values = sorted(test_data[treatment_col].unique())
    
    for v  in treatment_values:
        if v == 0.0:
            continue
        p_treat_name = "p_treatment_" + str(v)
        uplift_name = "uplift_" + str(v)
        test_data[uplift_name] = test_data[p_treat_name] - test_data["p_treatment_0.0"]
    return test_data


def evaulate_p_label_in_multi_treatment_online(tmp_model, test_data, base_indexs,model_select = "cat", treatment_col = 'treatment_col'):
    treatment_values = [0.0,2.0,3.0,4.0,5.0]
    all_feature = base_indexs



    for v  in treatment_values:
        p_treat_name = "p_treatment_" + str(v)
        fill_v = np.full((test_data.shape[0], 1),v)
        if model_select ==  "cat":
            test_data[p_treat_name] = tmp_model.predict_proba(np.hstack((np.vstack(test_data.dense_vector.values)[:,base_indexs], fill_v)))[:,1]
        elif model_select ==  "lgb":
            test_data[p_treat_name] = tmp_model.predict(
                np.hstack((np.vstack(test_data.dense_vector.values)[:, base_indexs], fill_v)))
        print(f"treatment: {v}, shape: {test_data[p_treat_name].shape},  p_score_avg: {test_data[p_treat_name].mean()} ")


    return test_data

def calculate_uplift_online(test_data, treatment_col='treatment_col'):
    treatment_values = [0.0,2.0,3.0,4.0,5.0]

    for v in treatment_values:
        if v == 0.0:
            continue
        p_treat_name = "p_treatment_" + str(v)
        uplift_name = "uplift_" + str(v)
        test_data[uplift_name] = test_data[p_treat_name] - test_data["p_treatment_0.0"]
    return test_data


from pylift.eval import UpliftEval
def plot_uplift(test_data, treatment_col = 'treatment_col'):
    test_data = test_data.copy()
    treatment_values = sorted(test_data[treatment_col].unique())
    
    for v  in treatment_values:
        if v == 0.0:
            continue
        uplift_name = "uplift_" + str(v)
        plot_df = pd.concat([test_data[test_data[treatment_col] == 0.0],test_data[test_data[treatment_col] == v]], ignore_index=True)
        plot_df['w'] = plot_df[treatment_col].apply(lambda x: 0 if x==0.0 else 1)

        
        upev = UpliftEval(plot_df['w'], plot_df['label'], plot_df[uplift_name], n_bins=100)
        test_Q_cgains = upev.Q_cgains
        print(uplift_name, test_Q_cgains)
        upev.plot( plot_type='cgains', label=f'uplift models auuc：{round(test_Q_cgains, 5)} ')
        plt.show()


def read_feature_config(file="feature_config/线上活跃用的特征.txt", json_path = 'feature_config/feature_list.json'):
    def read_feature_json_config(filename):
        with open(filename, 'r', encoding='utf-8') as file:
            # 使用json.load()函数读取文件内容并将其转换为字典
            config = json.load(file)
        features_true_names = []
        for i in config['default']:
            features_true_names.append(i['name'])

        return features_true_names

    feature_names = read_feature_json_config(json_path)
    feature_index = {}
    index_feature = {}
    i = 0
    for fn in feature_names:
        feature_index[fn] = i
        index_feature[i] = fn
        i += 1

    res = []
    base_features = []

    with open(file, "r") as f:
        for i in f.readlines():
            base_features.append(i.strip())

    for bf in base_features:
        res.append(feature_index[bf])
    return res, base_features
    
    
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import simps

def plot_acculate_gain(df111, cols):

    def plot_gain_chart(df, ground_truth_col, pred_col, label):
        # 根据预测值进行排序
        df = df.sort_values(by=pred_col, ascending=False)

        # 计算累积百分比
        df['cumulative_percentage_customers'] = np.arange(1, len(df) + 1) / len(df)
        df['cumulative_percentage_ltv'] = df[ground_truth_col].cumsum() / df[ground_truth_col].sum()

        # 绘制增益图曲线
        plt.plot(df['cumulative_percentage_customers'], df['cumulative_percentage_ltv'], label=label)

        # 返回累积百分比数据用于计算面积
        return df['cumulative_percentage_customers'], df['cumulative_percentage_ltv']

    # 绘制增益图
    plt.figure(figsize=(10, 6))

    aucs = {}
    for col in cols:
        x, y = plot_gain_chart(df111, 'Ground Truth', col, col)
        auc = simps(y, x)  # 计算面积
        aucs[col] = auc

    plt.xlabel('Cumulative Percentage of Customers')
    plt.ylabel('Cumulative Percentage of Total LTV')
    plt.title('Gain Chart')
    plt.legend()
    plt.grid(True)
    
    plt.show()
    
    # 打印每条曲线的面积
    for col, auc in aucs.items():
        print(f'AUC for {col}: {auc}')
        
    
    
def read_feature_config(file = "feature_config/线上活跃用的特征.txt"):
    
    def read_feature_json_config(filename):
        with open(filename, 'r', encoding='utf-8') as file:
            # 使用json.load()函数读取文件内容并将其转换为字典
            config = json.load(file)
        features_true_names = []
        for i in config['default']:
            features_true_names.append(i['name'])

        return features_true_names
    feature_names = read_feature_json_config('feature_config/feature_list.json')
    feature_index = {}
    index_feature = {}
    i = 0
    for fn in feature_names:
        feature_index[fn] = i 
        index_feature[i] = fn 
        i += 1
        
    res = [] 
    base_features = []
    
    with open(file, "r") as f:
        for i in f.readlines():
            base_features.append(i.strip())
    
    for bf in base_features:
        res.append(feature_index[bf])
    return res, base_features
    
    
def show_lgb_top_features_v2(model, feature_names, topk=20, output_path='feature_importance.csv'):
    # Load the models from the file
    tmp_model = model

    # Get feature importance values
    importance_values = model.feature_importances_

    # Calculate the total importance for percentage calculation
    total_importance = sum(importance_values)

    # Create a dictionary mapping feature names to their importance values
    feature_importance_dict = dict(zip(feature_names + ['is_treatment'], importance_values))

    # Sort the features by importance value in descending order
    sorted_features = sorted(feature_importance_dict.items(), key=lambda item: item[1], reverse=True)

    # Get the top k features, their importance values, and calculate their percentage
    top_features = sorted_features[:topk]
    top_features_with_percentages = [
        (feature, importance, importance / total_importance * 100)
        for feature, importance in top_features
    ]

    for feature, importance, percentage in top_features_with_percentages:
        print(f"Feature: {feature}, Importance: {importance}, Percentage: {percentage:.2f}%")

    # Create a DataFrame from the top features
    df = pd.DataFrame(top_features_with_percentages, columns=['Feature', 'Importance', 'Percentage'])

    # Save the DataFrame to a CSV file
    df.to_csv(output_path, index=False)

    return top_features_with_percentages
    
    
    
    
def send_df(msg_content, title_name = ''):
    """
    发送邮件，将传入的 DataFrame 内容嵌入到邮件正文。

    :param msg_content: 待发送的 DataFrame
    """
    subject = '实验结果' + title_name
    from_addr = 'tangweize@tuhu.cn'
    password = 'w2TrcT3ncb79X9ki'
    receivers = ['tangweize@tuhu.cn']
    smtp_server = 'smtp.exmail.qq.com'

    # 设置邮件内容
    msg = MIMEMultipart()
    msg['From'] = Header(from_addr)
    msg['To'] = Header(",".join(receivers))
    msg['Subject'] = Header(subject, 'utf-8')

    # 将 DataFrame 转换为 HTML 并嵌入到邮件正文
    html_content = "<h3>特征异常警告</h3><br>" + msg_content.to_html(index=False)
    msg.attach(MIMEText(html_content, 'html', 'utf-8'))

    # 发送邮件
    try:
        with smtplib.SMTP_SSL(smtp_server, 465) as smtpobj:
            smtpobj.login(from_addr, password)
            smtpobj.sendmail(from_addr, receivers, msg.as_string())
        print("邮件发送成功")
    except smtplib.SMTPException as e:
        print("无法发送邮件", e)